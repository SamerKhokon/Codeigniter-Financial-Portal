<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dailytop_looser_data extends CI_Model 
{
	
	public function dailytop_looser_by_price()
	{
	   $str = "SELECT Company_Code,Prev_Close_Price,Close_Price,
		((Close_Price-Prev_Close_Price)/Prev_Close_Price)*100 AS Percent_Change
		FROM `v_instrument_trade_status_web` where No_of_Trades>0
		ORDER BY Percent_Change ASC LIMIT 10";
		return $this->db->query($str)->result();
	}	
	
	public function dailytop_looser_by_percent_change()
	{
	    $str = "SELECT Company_Code,
	   ((Close_Price-Prev_Close_Price)/Prev_Close_Price)*100 AS Percent_Change FROM 
       `v_instrument_trade_status_web` where No_of_Trades>0
	   ORDER BY Percent_Change ASC LIMIT 10";
	  return $this->db->query($str)->result();	
	}
	
    public function dailytop_looser_by_volume_data()
	{
		$str = "SELECT company_code,volume FROM 
			`v_instrument_trade_status_web` 
			 where No_of_Trades>0
			ORDER BY volume ASC LIMIT 10";
		return $this->db->query($str)->result();
	}
	
    public function dailytop_looser_by_no_of_trades_data()
	{
		$str = "SELECT company_code,no_of_trades FROM 
			`v_instrument_trade_status_web` 
			where no_of_trades >0
			ORDER BY no_of_trades ASC LIMIT 10";
		return $this->db->query($str)->result();
	}	
	
	
    public function dailytop_looser_by_value_data()
	{
		$str = "SELECT company_code,turnover FROM 
		`v_instrument_trade_status_web` 
		where  No_of_Trades>0
		ORDER BY turnover ASC LIMIT 10";
		return $this->db->query($str)->result();
	}		
	
    public function dailytop_looser_by_turnover_data()
	{
		$str = "SELECT company_code,turnover FROM 
		`v_instrument_trade_status_web` 
		where No_of_Trades>0
		ORDER BY turnover ASC LIMIT 10";
		return $this->db->query($str)->result();
	}			
	
    public function dailytop_looser_by_pe_data()
	{
		$str = "SELECT company_code,pe FROM `mkt_pe_info`
				
				ORDER BY pe ASC LIMIT 10";
		return $this->db->query($str)->result();
	}		

    public function dailytop_looser_by_eps_data()
	{
	    $str = " SELECT COMPANY_CODE,ANNUALIZED_EPS,YEAR FROM(
				SELECT `COMPANY_CODE` , `ANNUALIZED_EPS` , `YEAR`
				FROM `mkt_company_gen_fin_info`
				ORDER BY ID DESC) AS t  GROUP BY company_code
				ORDER BY ANNUALIZED_EPS ASC";
	
		return $this->db->query($str)->result();			
	}	
	
	public function dailytop_looser_by_marketcap_data()
	{
		$str = "SELECT company_code,market_cap 
				FROM `mkt_share_info`
					ORDER BY market_cap ASC LIMIT 10";
					
		return $this->db->query($str)->result();				
	}

	
}
?>