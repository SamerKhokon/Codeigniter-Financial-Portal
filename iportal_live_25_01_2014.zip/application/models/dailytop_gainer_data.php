<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dailytop_gainer_data extends CI_Model 
{


    public function trade_status_table_data($field,$order)
	{
	    if($field=="")
		$where = "";
		else
		$where = "ORDER BY $field $order";		
	    $str = "SELECT Company_Code,Last_Traded_Price,Turnover,Volume,No_of_Trades,
		        ((Close_Price-Prev_Close_Price)/Prev_Close_Price)*100 as Percent_Change, 
				(SELECT MARKET_CAP FROM mkt_share_info WHERE company_code=a.company_code) AS market_cap ,
				(SELECT ANNUALIZED_EPS FROM(SELECT `COMPANY_CODE` , `ANNUALIZED_EPS` , `YEAR`
FROM `mkt_company_gen_fin_info` ORDER BY ID DESC) AS t  WHERE 
t.company_code=a.company_code
GROUP BY company_code ORDER BY ANNUALIZED_EPS DESC) AS eps
				FROM `v_instrument_trade_status_web`  as  a
				where No_of_Trades>0 ".$where;
		//return $str;		
		return $this->db->query($str)->result();		
	}
    
    public function dailytop_gainer_by_price()
	{
	   $str = "SELECT Company_Code,Prev_Close_Price,Close_Price,
		((Close_Price-Prev_Close_Price)/Prev_Close_Price)*100 AS Percent_Change
		,Last_Traded_Price
		FROM `v_instrument_trade_status_web` where No_of_Trades>0
		ORDER BY Percent_Change DESC LIMIT 10";
		return $this->db->query($str)->result();
	}

	public function dailytop_gainer_by_percent_change()
	{
	   $str = "SELECT Company_Code,
	   ((Close_Price-Prev_Close_Price)/Prev_Close_Price) AS Percent_Change FROM 
       `v_instrument_trade_status_web` where No_of_Trades>0
	   ORDER BY Percent_Change DESC LIMIT 10";
	  return $this->db->query($str)->result();
	}
	
	
    public function dailytop_gainer_by_volume_data()
	{
		$str = "SELECT company_code , volume FROM 
			`v_instrument_trade_status_web` where No_of_Trades>0
			ORDER BY volume DESC LIMIT 10";
		return $this->db->query($str)->result();
	}
	
    public function dailytop_gainer_by_no_of_trades_data()
	{
		$str = "SELECT company_code , no_of_trades FROM 
			`v_instrument_trade_status_web` where No_of_Trades>0
			ORDER BY no_of_trades DESC LIMIT 10";
		return $this->db->query($str)->result();
	}	
	
	
    public function dailytop_gainer_by_value_data()
	{
		$str = "SELECT company_code , turnover FROM 
		`v_instrument_trade_status_web` where No_of_Trades>0
		ORDER BY turnover DESC LIMIT 10";
		return $this->db->query($str)->result();
	}		
	
	
    public function dailytop_gainer_by_turnover_data()
	{
		$str = "SELECT company_code , turnover FROM 
		`v_instrument_trade_status_web` where No_of_Trades>0
		ORDER BY turnover DESC LIMIT 10";
		return $this->db->query($str)->result();
	}			
	
    public function dailytop_gainer_by_pe_data()
	{
		$str = "SELECT company_code , pe FROM `mkt_pe_info` 
				ORDER BY pe DESC LIMIT 10";
		return $this->db->query($str)->result();
	}		


    public function dailytop_gainer_by_eps_data()
	{
	    $str = "SELECT COMPANY_CODE,ANNUALIZED_EPS,YEAR FROM(
				SELECT `COMPANY_CODE` , `ANNUALIZED_EPS` , `YEAR`
				FROM `mkt_company_gen_fin_info`
				ORDER BY ID DESC) AS t  GROUP BY company_code 
				ORDER BY ANNUALIZED_EPS DESC";
		return $this->db->query($str)->result();			
	}
	
	public function dailytop_gainer_by_marketcap_data()
	{
	    $str = "SELECT company_code,market_cap 
					FROM `mkt_share_info`
					ORDER BY market_cap DESC LIMIT 10";
		return $this->db->query($str)->result();			
	}
	
	public function dailytop_gainer_by_turnover_growth_data()
	{
	   $str = "select company_code,annualized_eps from
	   mkt_gen_fin_info order by annualized_eps desc limit 10";
	   return $this->db->query($str)->result();
	}
	
}
?>