<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Weeklytop_looser_data extends CI_Model 
{
	public function dailytop_looser_by_percent_change()
	{
	    $str = "SELECT Trade_Date,Company_Code,
			SUM(Prev_Close_Price) Prev_Close_Price,SUM(Close_Price) Close_Price,
			SUM(((Last_Traded_Price-Prev_Close_Price)/Prev_Close_Price)*100) AS Percent_Change
			,SUM(Last_Traded_Price) Last_Traded_Price
			FROM `v_instrument_trade_status_web`   WHERE No_of_Trades > 0
			AND DATE_FORMAT(Trade_Date , '%Y-%m-%d') 
			BETWEEN DATE_SUB(DATE_FORMAT(NOW() , '%Y-%m-%d'),INTERVAL 7 DAY)
			AND DATE_FORMAT(NOW() , '%Y-%m-%d')
			GROUP BY Company_Code 
			ORDER BY Percent_Change ASC LIMIT 10";
	  return $this->db->query($str)->result();	
	}
	
    public function dailytop_looser_by_volume_data()
	{
		$str = "SELECT Trade_Date,Company_Code,			
				SUM(Volume) AS Volume			
				FROM `v_instrument_trade_status_web` WHERE No_of_Trades>0
				AND DATE_FORMAT(Trade_Date,'%Y-%m-%d') 
				BETWEEN DATE_SUB(DATE_FORMAT(NOW(),'%Y-%m-%d'),INTERVAL 7 DAY)
				AND DATE_FORMAT(NOW(),'%Y-%m-%d')
				GROUP BY Company_Code 
				ORDER BY Volume ASC LIMIT 10";
		return $this->db->query($str)->result();
	}
	
    public function dailytop_looser_by_no_of_trades_data()
	{
		$str = "SELECT Trade_Date,Company_Code,			
				SUM(No_of_Trades) AS No_of_Trades			
				FROM `v_instrument_trade_status_web` WHERE No_of_Trades>0
				AND DATE_FORMAT(Trade_Date,'%Y-%m-%d') 
				BETWEEN DATE_SUB(DATE_FORMAT(NOW(),'%Y-%m-%d'),INTERVAL 7 DAY)
				AND DATE_FORMAT(NOW(),'%Y-%m-%d')
				GROUP BY Company_Code 
				ORDER BY No_of_Trades ASC LIMIT 10";
		return $this->db->query($str)->result();
	}
	
	public function dailytop_looser_by_turnover_data()
	{
		$str = "SELECT Trade_Date,Company_Code,			
				SUM(Turnover) AS Turnover			
				FROM `v_instrument_trade_status_web` WHERE No_of_Trades>0
				AND DATE_FORMAT(Trade_Date,'%Y-%m-%d') 
				BETWEEN DATE_SUB(DATE_FORMAT(NOW(),'%Y-%m-%d'),INTERVAL 7 DAY)
				AND DATE_FORMAT(NOW(),'%Y-%m-%d')
				GROUP BY Company_Code 
				ORDER BY Turnover ASC LIMIT 10";
		return $this->db->query($str)->result();
	}			

}
?>