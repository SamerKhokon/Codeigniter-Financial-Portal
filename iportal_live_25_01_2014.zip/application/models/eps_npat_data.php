<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eps_npat_data extends CI_Model 
{	
    public function get_sectors()
	{
	    $str = "SELECT DISTINCT CODE FROM 
				`company_basic_info` ORDER BY CODE ASC";
		$res = $this->db->query($str)->result();		
		return $res;
	}
	
	public function share_distribution_data($company_code)
	{
	    //$company_code = "ACI";
	    $str = "SELECT  `SPONSOR`,`GOVT`,`INSTITUTE`,`FOREIGN`,`PUBLIC` as `PUBLICS`
				FROM `mkt_share_info` WHERE COMPANY_CODE='$company_code' 
				ORDER BY id DESC LIMIT 1";
	  
	    $res = $this->db->query($str)->result();
		return $res[0]->SPONSOR .'#'. $res[0]->GOVT .'#'. $res[0]->INSTITUTE 
		.'#'. $res[0]->FOREIGN  .'#'. $res[0]->PUBLICS;
	}
	
	public function scope_to_pay_divident_data($company_code)
	{
	   //$company_code = "ACI";
	   /*
	    $str = "SELECT MARKET_CAP,
				(SELECT PAIDUP_CAP  FROM `mkt_paidup_cap_info` ORDER BY ID DESC LIMIT 1) 
				AS PAIDUP_CAP FROM `mkt_share_info` WHERE COMPANY_CODE='$company_code'
			ORDER BY ID DESC LIMIT 1";*/
			
		$str = "SELECT MARKET_CAP,
			((SELECT PAIDUP_CAP  FROM `mkt_paidup_cap_info` WHERE company_code='$company_code' ORDER BY ID DESC LIMIT 1)/
			(SELECT `AUTHORIZED_CAP`  FROM `mkt_share_info` WHERE company_code='$company_code' ORDER BY ID DESC LIMIT 1))*100 AS NPAID_UP
			,100-(((SELECT PAIDUP_CAP  FROM `mkt_paidup_cap_info` WHERE company_code='$company_code' ORDER BY ID DESC LIMIT 1)/
			(SELECT `AUTHORIZED_CAP`  FROM `mkt_share_info` WHERE company_code='$company_code' ORDER BY ID DESC LIMIT 1))*100) AS SCOPE
			FROM `mkt_share_info` WHERE COMPANY_CODE='$company_code'
			ORDER BY ID DESC LIMIT 1"	;
	  
	    $res = $this->db->query($str)->result();
		return $res[0]->NPAID_UP  .'#'.  $res[0]->SCOPE;
	}
	
	
	
	
	
	public function eps_continuing_years_data($company_code)
	{
	    //$company_code = "ACI";
	    $str = "SELECT `YEAR` FROM 
				`mkt_eps_continuing_operation_info`
				WHERE COMPANY_CODE='$company_code'";
		return  $this->db->query($str)->result();		
	}
		
	
	public function eps_continuing_first_quarter_data($company_code)
	{
	    //$company_code = "ACI";
	    $str = "SELECT `QUARTER_1_3M`,`QUARTER_2_3M`,`QUARTER_3_3M`,`QUARTER_4_3M` FROM 
				`mkt_eps_continuing_operation_info`
				WHERE COMPANY_CODE='$company_code'";
		return  $this->db->query($str)->result();		
	}	
	
	public function eps_continuing_all_quarter_data($company_code)
	{
	    //$company_code = "ACI";
	    $str = "SELECT `QUARTER_1_3M`,`QUARTER_2_6M`,
				`QUARTER_3_9M`,`QUARTER_4_12M` FROM 
				`mkt_eps_continuing_operation_info`
				WHERE COMPANY_CODE='$company_code'";
		return  $this->db->query($str)->result();
	}
	
	
	public function yearly_eps_data($company_code)
	{
		//$company_code = "ACI";
		$str = "SELECT `YEAR`,`QUARTER_4_12M` FROM `mkt_eps_continuing_operation_info`
				WHERE COMPANY_CODE='$company_code'";
				
		return $this->db->query($str)->result();		
	}
	
	
	
	
	public function net_profit_year_continuing_data($company_code)
	{  
	    //$company_code = "ACI";
	    $str = "SELECT `YEAR` FROM 
		`mkt_net_profit_after_tax_continuing_operation_info`
		WHERE COMPANY_CODE='$company_code'";
		return  $this->db->query($str)->result();
	}
	
	
	public function net_profit_first_quarter_continuing_data($company_code)
	{
		//$company_code = "ACI";
	    $str = "SELECT `QUARTER_1_3M`,`QUARTER_2_3M`,`QUARTER_3_3M`,`QUARTER_4_3M` FROM 
				`mkt_net_profit_after_tax_continuing_operation_info`
				WHERE COMPANY_CODE='$company_code'";
		return  $this->db->query($str)->result();	
	}
	
	public function net_profit_all_quarter_continuing_data($company_code)
	{
		//$company_code = "ACI";
	    $str = "SELECT `QUARTER_1_3M`,`QUARTER_2_6M`,
				`QUARTER_3_9M`,`QUARTER_4_12M` FROM 
			`mkt_net_profit_after_tax_continuing_operation_info`
			WHERE COMPANY_CODE='$company_code'";
		return  $this->db->query($str)->result();	
	}	
	
	
	
	
	public function yearly_nav_data($company_code)
	{
	    //$company_code = "ACI";
	    $str = "SELECT `YEAR` FROM 
		`mkt_company_gen_fin_info`
		WHERE COMPANY_CODE='$company_code'";
		
		return  $this->db->query($str)->result();	
	}
	
	
	public function yearly_nav_shares_data($company_code)
	{
	   // $company_code = "ACI";
	    $str = "SELECT NAV_PERSHARE FROM 
		`mkt_company_gen_fin_info`
		WHERE COMPANY_CODE='$company_code'";
		
		return  $this->db->query($str)->result();	
	}	
	
}
?>