<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Divident_details_data extends CI_Model 
{


	public function divident_cash_find_for_all_index()
	{
		$str = "SELECT `COMPANY_CODE`,`INTERIM_DIVIDEND_CASH`,`FINAL_DIVIDEND_CASH`,`YEAR`,
	   `INTERIM_DIVIDEND_STOCK`,`FINAL_DIVIDEND_STOCK`,`INTERIM_DIVIDEND_DECLARATION_DATE`,
		`FINAL_DIVIDEND_DECLARATION_DATE`
		FROM `mkt_divident_info`";
		return $this->db->query($str)->result();	
	}

	
	public function divident_cash_for_a_sector($sector,$years)
	{
	    //$sector = "Bank";
	    //$years = 2000;
	    $str = "SELECT `COMPANY_CODE`,`INTERIM_DIVIDEND_CASH`,`FINAL_DIVIDEND_CASH`,
				`YEAR`,`INTERIM_DIVIDEND_STOCK`,`FINAL_DIVIDEND_STOCK`,
				`INTERIM_DIVIDEND_DECLARATION_DATE`,`FINAL_DIVIDEND_DECLARATION_DATE`
				FROM `mkt_divident_info` WHERE COMPANY_CODE 
				IN(SELECT CODE FROM `company_basic_info`
				WHERE SECTOR='$sector') AND YEAR IN($years)";	
		return $this->db->query($str)->result();		
		//return $str;
	}
	
	

    public function divident_cash_find($years , $companies)
	{
	   $str = "SELECT `COMPANY_CODE`,`INTERIM_DIVIDEND_CASH`,`FINAL_DIVIDEND_CASH`,`YEAR`,
	   `INTERIM_DIVIDEND_STOCK`,`FINAL_DIVIDEND_STOCK`,`INTERIM_DIVIDEND_DECLARATION_DATE`,
		`FINAL_DIVIDEND_DECLARATION_DATE`
		FROM `mkt_divident_info` WHERE COMPANY_CODE IN($companies)
			AND YEAR IN($years)";
		return $this->db->query($str)->result();	
	}
	
	public function eps_of_a_company($year , $company_code)
	{
	    $str  = "SELECT `ANNUALIZED_EPS` FROM `mkt_company_gen_fin_info`
		WHERE COMPANY_CODE='$company_code' AND `YEAR`=$year";
		$res = $this->db->query($str)->result();
		if($res[0]->ANNUALIZED_EPS !="")
		return $res[0]->ANNUALIZED_EPS;
		else
		return 0; 
	}
	
	
	public function get_last_traded_price()
	{
		$str = "SELECT  Trade_Date,Last_Traded_Price
				FROM `v_instrument_trade_status_web`
				ORDER BY Trade_Date DESC LIMIT 1";
		$res = $this->db->query($str)->result();
		return $res[0]->Last_Traded_Price;		
	}
	
	
	public function get_sector_category($company_code)
	{
	    $str = "SELECT CODE,CATEGORY,SECTOR FROM `company_basic_info`
				WHERE CODE='$company_code' order by SLNO desc limit 1";
		$res = $this->db->query($str)->result();		
		return $res[0]->CODE .'#' . $res[0]->CATEGORY .'#' . $res[0]->SECTOR;
	}
}	
?>