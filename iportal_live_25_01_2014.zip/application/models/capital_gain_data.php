<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Capital_gain_data extends CI_Model 
{	   

    public function get_end_price($date,$company_code)
	{
		$str = "SELECT `MKISTAT_CLOSE_PRICE`
			FROM mkt_eod 
			WHERE `MKISTAT_INSTRUMENT_CODE`='$company_code' 
			AND DATE_FORMAT(`MKISTAT_LM_DATE_TIME`,'%d-%m-%Y')='$date'";
				
		//return	 $str;
		if( $this->db->query($str)->num_rows() <= 0 )
			return 0;		
		else
			$res = $this->db->query($str)->result();	
			return $res[0]->MKISTAT_CLOSE_PRICE;
	}
}
?>	