<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Divident_details_json_data extends CI_Model 
{
    public function ty($years , $company_code)
	{
       $str = "SELECT `INTERIM_DIVIDEND_CASH`,`INTERIM_DIVIDEND_STOCK`,
		`FINAL_DIVIDEND_CASH`,`FINAL_DIVIDEND_STOCK` FROM `mkt_divident_info`
		WHERE company_code IN($company_code) AND YEAR IN($years)";
	   $res = $this->db->query($str)->result();	 
	   
	   return $res;
    }
	
	public function option_two_json_data($sector , $years)
	{
	    $str = "SELECT `COMPANY_CODE`,`YEAR`,`INTERIM_DIVIDEND_CASH`,`INTERIM_DIVIDEND_STOCK`,
		`FINAL_DIVIDEND_CASH`,`FINAL_DIVIDEND_STOCK`
		FROM `mkt_divident_info` WHERE 
			`COMPANY_CODE` IN(SELECT `CODE` FROM `company_basic_info`
			WHERE SECTOR='$sector') AND YEAR IN($years)"; 
		return $this->db->query($str)->result();		
	}
	
	
	
	public function option_three_json_data()
	{
	    $str = "SELECT `COMPANY_CODE`,`YEAR`,`INTERIM_DIVIDEND_CASH`,`INTERIM_DIVIDEND_STOCK`
				,`FINAL_DIVIDEND_CASH`,`FINAL_DIVIDEND_STOCK`
				FROM `mkt_divident_info` ";
		return $this->db->query($str)->result();		
	}
}
?>