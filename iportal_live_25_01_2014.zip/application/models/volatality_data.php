<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Volatality_data extends CI_Model 
{

    public function get_all_numbers($start_date,$end_date,$codes)
	{
	   $str = "SELECT val FROM `tbl_sdv`
				WHERE company = '$codes' AND 
				dates BETWEEN '$start_date' AND '$end_date'";
	   $res = $this->db->query($str)->result();
	   return $res;
	}
   
    public function get_total_numbers($start_date,$end_date,$codes)
	{
	   $str = "SELECT COUNT(*) TOTAL_NUMBERS FROM `tbl_sdv`
				WHERE company = '$codes' AND 
				dates BETWEEN '$start_date' AND '$end_date'";
	   $res = $this->db->query($str)->result();
	   return $res[0]->TOTAL_NUMBERS;
	}
	
	public function get_sum($start_date,$end_date,$codes)
    {
		$str = "SELECT SUM(val) SUMMATION FROM `tbl_sdv`
				WHERE company = '$codes' AND
				dates BETWEEN '$start_date' AND '$end_date'";
	   $res = $this->db->query($str)->result();
	   return $res[0]->SUMMATION;
	   //return $str; 
	}
	
	public function get_dates($beg,$end,$code)
	{
	    $beg = date("Y-m-d" , strtotime($beg));
		$end = date("Y-m-d" , strtotime($end));
		
	    $str = "SELECT DISTINCT dates,DATE_FORMAT(dates,'%W') AS days FROM `tbl_sdv`
				WHERE company='$code' AND
				dates BETWEEN '".$beg."' AND '".$end."'
					AND (DATE_FORMAT(dates,'%W')!='Friday' 
					AND DATE_FORMAT(dates,'%W')!='Saturday')  
				ORDER BY dates ASC";
				
		return $this->db->query($str)->result();		
	
	}
	
}
?>	