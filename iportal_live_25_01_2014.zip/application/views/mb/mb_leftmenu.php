	<table>
		<!--
		<tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="sub_menu_add_ui" value="Add Submenu"/></td></tr>
		-->
		<tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="importer_add_ui" value="Import Information"/></td></tr>
		
		<!-- <tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="company_info_ui" value="Company Information"/></td></tr>																				-->
		<tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="company_logo_upload_ui" value="Company Logo Import"/></td></tr>																						
		<tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="manual_entry_form_ui" value="Manual Entry Form"/></td></tr>																														
		<tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="management_info_entry_form_ui" value="Management Entry Form"/></td></tr>	
		<tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="company_info_manual_entry_form_ui" value="Company Manual Entry Form"/></td></tr>			
		
		
		<tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="divident_detail_ui" value="Dividend Detail Entry"/></td></tr>				
		
		<!--
		<tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="div_ui" value="Divident Graph Test"/></td></tr>						
		<tr><td><input type="button" name="sub" class="btn btn-primary" style="width:200px;" id="eps_npat_ui" value="EPS & NPAT"/></td></tr>								
		-->
	</table>