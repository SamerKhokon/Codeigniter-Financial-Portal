	<!-- bootstrap -->
    <link href="<?php echo base_url();?>css/bootstrap.min.css" rel="stylesheet" media="screen">
  
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>themes/base/jquery.ui.all.css">	
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/custom.css">	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>css/menu.css">	
	
	
	<script src="<?php echo base_url();?>js/jquery-1.10.1.min.js"></script>
	
	
	<script src="<?php echo base_url();?>js/custom.js"></script>

	<!-- jquery ui datepicker -->
	<script src="<?php echo base_url();?>ui/jquery.ui.core.js"></script>
	<script src="<?php echo base_url();?>ui/jquery.ui.datepicker.js"></script>
		
	
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>media/css/demo_page.css">		
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>media/css/demo_table.css">			
	<script src="<?php echo base_url();?>media/js/jquery.dataTables.min.js"></script>


    