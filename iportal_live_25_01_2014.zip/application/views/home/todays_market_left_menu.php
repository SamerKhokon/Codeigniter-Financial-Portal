<div class="sidebar-menu">
	<ul class="nav">
		<li class="dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Market Stats<span class="glyphicon glyphicon-chevron-right"></span></a>
			<ul class="dropdown-menu">
			<li class="active"><a href="http://capm.smartsolutionpro.us/iportal/market/index.php">Stock Market</a></li>
			<li><a href="#">Money Market</a></li>
			<li><a href="#">Commodity</a></li>
			<li><a href="#">Bonds</a></li>
			<li><a href="#">Currency</a></li>
			<li><a href="#">Economic Indicators</a></li>
			<li><a href="#">Global Capital Market</a></li>
		   </ul>
		</li>
		<li><a href="http://capm.smartsolutionpro.us/iportal/market/sectorIndex.php">Sector Index Change</a></li>
		<li><a href="http://capm.smartsolutionpro.us/iportal/market/indexMovers.php">Index Movers</a></li>
		<li><a href="http://capm.smartsolutionpro.us/iportal/market/marketMovers.php">Market Movers</a></li>
		<li><a href="#">Monitor Your Stock</a></li>
		<li><a href="#">Minute Chart</a></li>
		<li><a href="#">Technical Chart</a></li>
		<li><a href="http://capm.smartsolutionpro.us/iportal/market/company_info.php">Decision Page</a></li>
	</ul>
</div>