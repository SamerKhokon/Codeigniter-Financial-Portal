<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home</title>

<?php $this->load->view("utility"); ?>

</head>
<body>
<div class="container"> 
 
    <!---header start----->	
    <div class="row">
		<?php $this->load->view("home/capm_header");?>
    </div>	
	
    <div class="row">
		<div class="col-md-12  placeholder">  </div>
	</div>

	<div class="row">
		<?php $this->load->view("home/capm_megamenu");?>
	</div> 
    <!---header end----> 

      

	  
	  
	  
    <!--body start---->
	<div class="row"> 

		<!--static sidebar menu---->
		<div class="col-md-3">
			<?php $this->load->view("home/company_fundamental_quantitative_left_menu");?>
		</div>
		<!--static sidebar menu end--->
		
		
		<div class="col-md-9">

			<div class="row">
				<div class="col-md-12 placeholder">
									<?php $this->load->view("home/company_fundamental_quantitative_submenu_overview");?>
				</div>
			</div>

			<?php   $codes1 = $this->load->get_var('codes1');		?>				
				
				
		<br/><br/>
		
		<div class="panel panel-default">
			<div class="panel-heading" style="background-color:#999966;font-family: tahoma,Arial;">Option 1</div>
			<div class="panel-body">
				<table width="100%">
					<tr>
					  <td><input type="checkbox" name="divident_details_years" value="2000"/>&nbsp;2000</td>
					  <td><input type="checkbox" name="divident_details_years" value="2001" />&nbsp;2001</td>
					  <td><input type="checkbox" name="divident_details_years" value="2002" />&nbsp;2002</td>
					  <td><input type="checkbox" name="divident_details_years" value="2003" />&nbsp;2003</td>
					</tr> 
				</table>		
				<table width="100%">
					<tr>
					  <td><select id="company_code_01" >
					      <option value="">select company</option>
						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_02" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_03" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_04" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					</tr> 
					<tr>
					  <td><select id="company_code_05" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_06" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_07" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_08" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					</tr> 
					<tr>
					  <td><select id="company_code_09" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_10" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_11" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_12" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					</tr> 
					<tr>
					  <td><select id="company_code_13" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_14" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_15" >
					  <option value="">select company</option>
						  						  <?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					  <td><select id="company_code_16" >
					  <option value="">select company</option>
						<?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select></td>
					</tr> 
					<tr>
						<td>
							<select id="company_code_17" >	
							<option value="">select company</option>
							<?php foreach($codes1 as $code1){ ?>
						  <option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select>
						</td>
						<td>
							<select id="company_code_18" >
							<option value="">select company</option>
						  	<?php foreach($codes1 as $code1){ ?>
							<option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select>
						</td>
						<td>
							<select id="company_code_19" >
							<option value="">select company</option>
						  		<?php foreach($codes1 as $code1){ ?>
								<option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>						  
						  </select>
						</td>
						<td>
							<select id="company_code_20">
							<option value="">select company</option>
						  		<?php foreach($codes1 as $code1){ ?>
								<option value="<?php echo $code1->CODE;?>"><?php echo $code1->CODE;?></option>
						  <?php } ?>
						  </select>
						</td>
					</tr> 	
					<tr><td colspan="4">
					<input type="button" class="btn btn-primary" id="divident_detail_show_result_option_01" value="Show Result"/>
					</td></tr>
				</table>
		
			</div>
		</div>
		
		<div id="divident_search_result_option_001"></div>
		
		
		<div class="panel panel-default">
			<div class="panel-heading" style="background-color:#999966;font-family: tahoma,Arial;">Option 2</div>
			<div class="panel-body">
			
			    <table width="100%">
					<tr>
					  <td><input type="checkbox" name="option_2" value="2000"/>&nbsp;2000</td>
					  <td><input type="checkbox" name="option_2" value="2001"/>&nbsp;2001</td>
					  <td><input type="checkbox" name="option_2" value="2002"/>&nbsp;2002</td>
					  <td><input type="checkbox" name="option_2" value="2003"/>&nbsp;2003</td>
					</tr>
					<tr>
					  <td>Sector:</td>
					  <td>
					  <?php  $sects = $this->load->get_var('sects');
					  //= $this->input_form_data->get_sectors();?>
						<select id="sector_id" >
						   <option value="">select sector</option>
						   <?php foreach($sects as $sect){?>
						   <option value="<?php echo $sect->SECTOR;?>"><?php echo $sect->SECTOR;?></option>
						   <?php } ?>
						</select>						  
					  </td>
					  <td colspan="2">&nbsp;</td>
					</tr>
					<tr>
					 <td><input type="button" class="btn btn-primary" id="option_two_search_result_btn" value="Show Result"/></td>
					</tr>
				</table>	  
			  
			</div>
		</div>
		
		<div id="divident_search_result_option_002"></div>
		
		<div class="panel panel-default">
			<div class="panel-heading"  style="background-color:#999966;font-family: tahoma,Arial;">Option 3</div>
			<div class="panel-body">
			
			    <table width="100%">
					<tr>
					  <td><input type="checkbox" name="all_index" id="all_index" value="all_index"/></td>					
					</tr>
					<tr>
					<td><input type="button" id="divident_search_result_option_03_btn" class="btn btn-primary" value="Show Result"/></td>
					</tr>
				</table>	  
			  
			</div>
		</div>
		
		<div id="divident_search_result_option_003"></div>
		
		
		<script src="<?php echo base_url();?>js/charts/highcharts.js"></script>
		<script src="<?php echo base_url();?>js/charts/modules/exporting.js"></script>									  				  
		<div id="divident_search_graph"></div>
		
		
		<div id="divident_common_result"></div>
				
		
		
				
				
				<script type="text/javascript">
		$(document).ready(function(){
		/**
		** divident detail
		**/
		
		
		
		    $("#option_two_search_result_btn").bind("click",option_two_search_result_btn);
			
			function option_two_search_result_btn()
			{
			    var years = [];
				$("input[name='option_2']").each(function(){
					if($(this).is(':checked')==true){
						years.push($(this).val());
					}	
				}); 
				var sector_id= $("#sector_id").val();
				
				if(sector_id=="") {
				   alert("select sector");
				   return false;
				}else if(years.length==0){
				   alert("Select Year");
				   return false;
				}else{
					$.ajax({
						type:"post",
						url:"<?php echo site_url();?>/home/option_two_search_json",
						data:"years="+years+"&sector_id="+sector_id,
						dataType:'json' ,
						cache:false ,
						success:function(st){
						   
							var yrr = st[0].cats;
							var cm = st[st.length-1].coms;
							alert(cm);
							var t = [];
							$.each(st, function(k,v){
							    if(k>0 && k<st.length) {
								   t.push(v);
								}
							});
							
							
							var chart = new Highcharts.Chart({    
								chart: {
									type: 'column',
									renderTo: 'divident_search_result_option_002'
								},
								title:'',								
								xAxis: {
									categories: cm,//['Jan', 'Feb', 'Mar'],
									labels:{rotation:-55},
								},								
								plotOptions: {
									series: {
										stacking: 'normal'
									}
								},
                                exporting:{enabled:false},
								credits:{enabled:false},
								series: t
								
								 /*[
									{
										name: 'base',
										data: [10, 20, 30]
									},
									{
										name: 'sec',
										data: [30, 20, 10]
									}
								]*/
							});
											
							
						}
					});
				}
				
				$("#divident_common_result").load("<?php echo site_url();?>/home/divident_detail_option_two_search_result",
				{'years':years,'sector_id':sector_id},
				function(){});
				
				//alert(years+'  '+sector_id);
			}
		
		    $("#divident_search_result_option_03_btn").bind("click" , divident_search_result_option_03_btn);
		    function divident_search_result_option_03_btn()
		    {	        
			
			    $.ajax({ 
						type:"post",
						url:"<?php echo site_url();?>/home/all_companies_index_json" ,
						data:"1=1",
						cache:false,
						dataType:'json',
						success:function(st){
						    
							var cm = st[st.length-1].coms;
							var t = [];
							$.each(st , function(k,v){
							   if(k<st.length){
							     t.push(v);
							   }
							});
							
							
							var chart = new Highcharts.Chart({    
								chart: {
									type: 'column',
									renderTo: 'divident_search_result_option_003'
								},
								title:'',								
								xAxis: {
									categories: cm,//['Jan', 'Feb', 'Mar'],
									labels:{rotation:-55},
								},								
								plotOptions: {
									series: {
										stacking: 'normal'
									}
								},
                                exporting:{enabled:false},
								credits:{enabled:false},
								series: t
								
								 /*[
									{
										name: 'base',
										data: [10, 20, 30]
									},
									{
										name: 'sec',
										data: [30, 20, 10]
									}
								]*/
							});
							
							
							
						}
					});
			  
				$("#divident_common_result").load("<?php echo site_url();?>/home/divident_detail_option_three_search_result",
						function(){});
			}
		
		
		   $("#divident_detail_show_result_option_01").bind("click", divident_detail_show_result_option_01);
		    function divident_detail_show_result_option_01()
		    {
		        $("#divident_search_result_option_001").html("");
				 var company_code_01 = $("#company_code_01").val();
				 var company_code_02 = $("#company_code_02").val();
				 var company_code_03 = $("#company_code_03").val();
				 var company_code_04 = $("#company_code_04").val();
				 var company_code_05 = $("#company_code_05").val();
				 var company_code_06 = $("#company_code_06").val();
				 var company_code_07 = $("#company_code_07").val();
				 var company_code_08 = $("#company_code_08").val();
				 var company_code_09 = $("#company_code_09").val();
				 var company_code_10 = $("#company_code_10").val();
				 var company_code_11 = $("#company_code_11").val();
				 var company_code_12 = $("#company_code_12").val();
				 var company_code_13 = $("#company_code_13").val();
				 var company_code_14 = $("#company_code_14").val();
				 var company_code_15 = $("#company_code_15").val();
				 var company_code_16 = $("#company_code_16").val();
				 var company_code_17 = $("#company_code_17").val();
				 var company_code_18 = $("#company_code_18").val();
				 var company_code_19 = $("#company_code_19").val();
				 var company_code_20 = $("#company_code_20").val();			 	 
			  
			 
				var years = [];
				$("input[name='divident_details_years']").each(function(){
					if($(this).is(':checked')==true){
						years.push($(this).val());
					}	
				}); 
			 
				if(years.length>0)
				{	
					var dt = [];					
					$.ajax({
					   type:"post" ,
					   url:"<?php echo site_url();?>/home/tt" ,
					   data:"years="+years+"&company_code_01="+company_code_01+
					   "&company_code_02="+company_code_02+
					   "&company_code_03="+company_code_03+
					   "&company_code_04="+company_code_04+
					   "&company_code_05="+company_code_05+
					   "&company_code_06="+company_code_06+
					   "&company_code_07="+company_code_07+
					   "&company_code_08="+company_code_08+
					   "&company_code_09="+company_code_09+
					   "&company_code_10="+company_code_10+
					   "&company_code_11="+company_code_11+
					   "&company_code_12="+company_code_12+
					   "&company_code_13="+company_code_13+
					   "&company_code_14="+company_code_14+
					   "&company_code_15="+company_code_15+
					   "&company_code_16="+company_code_16+
					   "&company_code_17="+company_code_17+
					   "&company_code_18="+company_code_18+
					   "&company_code_19="+company_code_19,
					   dataType:"json" ,
					   success:function(st){
					      var yrr = st[0].cats;
						  var cm = st[1].coms;
						  
					     
						  var t = [];
					      $.each(st,function(k,v){
						    if(k>1){
								t.push(v);
						    }
						  });
						  //alert(t);
						  
						  
						 
						   var chart = new Highcharts.Chart({    
								chart: {
									type: 'column',
									renderTo: 'divident_search_result_option_001'
								},
								title:'',
								tooltip: {
									//pointFormat: "{point.cats}:{point.y}%"
									formatter: function() {
										return  'Company:'+ this.x	+ 
										'<br/>Year:'+ this.series.name +
										'<br/>Dividend:' +this.point.y + '%<br />' ;
									}
								},
								xAxis: {
									categories: cm,//['Jan', 'Feb', 'Mar'],
									labels:{rotation:-55},
								},								
								plotOptions: {
									series: {
										stacking: 'normal'
									}
								},
                                exporting:{enabled:false},
								credits:{enabled:false},
								series: t
								
								 /*[
									{
										name: 'base',
										data: [10, 20, 30]
									},
									{
										name: 'sec',
										data: [30, 20, 10]
									}
								]*/
							});
											  
						  
						  //alert(t);
					   }					   
					});				
				}
				else
				{
					$("#divident_search_result_option_001").html("");	
				} 
			 
			 
		     $("#divident_common_result").load("<?php echo site_url();?>/home/divident_detail_option_one_search_result",
			 {"years":years,"company_code_01":company_code_01, "company_code_02":company_code_02,
			 "company_code_03":company_code_03, "company_code_04":company_code_04,
			 "company_code_05":company_code_05, "company_code_06":company_code_06,
			 "company_code_07":company_code_07, "company_code_08":company_code_08,
			 "company_code_09":company_code_09, "company_code_10":company_code_10,
			 "company_code_11":company_code_11, "company_code_12":company_code_12,
			 "company_code_13":company_code_13, "company_code_14":company_code_14,
			 "company_code_15":company_code_15, "company_code_16":company_code_16,
			 "company_code_17":company_code_17, "company_code_18":company_code_18 ,
			 "company_code_19":company_code_19, 
			 "company_code_20":company_code_20} , function(){});
			 
			 
		    }
		});
		</script>		
							
			
			
			
			
			
			

		</div><!---the bottom tens---->

    </div>
	</div>


    <!--main column end for body---> 
    <!--body end--> 
<script type="text/javascript">
$(document).ready(function() {

    $("#comp_id").change(function(){
	
	   var sid  = $(this).val();
	   //alert(sid);
	   if(sid!=""){
	   $("#basic_info_result").load("<?php echo site_url();?>/company_basic_info_ui/ui",{"company_code":sid},function(){});
	   }else{
	   $("#basic_info_result").html("");
	   }
	});

	$('#example').dataTable( {
		"aaSorting": [[ 1, "ASC" ]],
		"bPaginate": false
	});	

    $('#accordion .panel-collapse').on('shown.bs.collapse', function () {
       $(".glyphicon-chevron-down").removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
    });
    $('#accordion .panel-collapse').on('hidden.bs.collapse', function () {
       $(".glyphicon-chevron-up").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
    });

				
	$('#dp3').datepicker({
    startDate: "24/09/2013",
    orientation: "bottom auto",
    autoclose: true
    });

	$(".input-group.date").datepicker({ autoclose: true, //todayHighlight: true
    startDate: "24/09/2013",
	orientation: "bottom auto",
	});

	$('#dp4').datepicker({
    autoclose: true
    });
} );
</script>
<script src="<?php echo base_url();?>js/bootstrap.js"></script>
<!--
<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
-->
</body>
</html>