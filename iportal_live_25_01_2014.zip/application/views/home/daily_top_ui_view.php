<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home</title>

<?php $this->load->view("utility"); ?>

</head>
<body>
<div class="container"> 
 
    <!---header start----->	
    <div class="row">
		<?php $this->load->view("home/capm_header");?>
    </div>	
	
    <div class="row">
		<div class="col-md-12  placeholder">  </div>
	</div>

	<div class="row">
		<?php $this->load->view("home/capm_megamenu");?>
	</div> 
    <!---header end----> 

      

	  
	  
	  
    <!--body start---->
	<div class="row"> 

		<!--static sidebar menu---->
		<div class="col-md-3">
			<?php $this->load->view("home/company_fundamental_quantitative_left_menu");?>
		</div>
		<!--static sidebar menu end--->
		
		
		
		
		
		
		
		<div class="col-md-9">

			<div class="row">
				<div class="col-md-12 placeholder">
					<?php $this->load->view("home/company_fundamental_quantitative_submenu_overview");?>
				</div>
			</div>

			
			


						<br/>		
						<input type="hidden" id="sel_flag" value=""/>
						<div  style="overflow:scroll;height:300px;">
						   <script type="text/javascript">
						    $(document).ready(function(){
							
							    $("#search_result").load("<?php echo site_url();?>/daily_top_ui/trade_status_table",
								{'keyword':'#'},function(){});	
							
							    $("#gainer_search_cat").change(function(){
								    var gainer_search_cat = $("#gainer_search_cat").val();
									if(gainer_search_cat!="") {
										//alert(gainer_search_cat);
										$("#search_result").load("<?php echo site_url();?>/daily_top_ui/trade_status_table",
										{'keyword':gainer_search_cat+'#asc'},function(){});						
							
									}else{
									    $("#search_result").load("<?php echo site_url();?>/daily_top_ui/trade_status_table",
										{'keyword':'#'},function(){});						
							
									}
								});
								 
								 
								$("#looser_search_cat").change(function(){
								     var looser_search_cat = $("#looser_search_cat").val();
									if(looser_search_cat!="") 
									{
									    //alert(looser_search_cat);
									 	$("#search_result").load("<?php echo site_url();?>/daily_top_ui/trade_status_table",
										{'keyword':looser_search_cat+'#desc'},function(){});						
							
									}
									else
									{
									  	$("#search_result").load("<?php echo site_url();?>/daily_top_ui/trade_status_table",
										{'keyword':looser_search_cat+'#desc'},function(){});						
																 
									}
								});
								 
								 
							});
						   </script>
						   <table width="100%">
						   <tr>
						       <td>Select Top Gainer:</td>
							   <td>&nbsp;</td>
							   <td>Select Top Looser:</td>
							</tr>
							<tr>		
							
							
								   <td><select id="looser_search_cat">
							          	<option value="">choose anyone</option>										  
							              <option value="No_of_trades">No of Trades</option>										  										     
							              <option value="Percent_Change">% Price</option>
							              <option value="Turnover">Turnover</option>
							              <option value="Volume">Volume</option>										  
							              <option value="market_cap">Market CAP</option>										  
							              <option value="eps">Eps</option>										  										  										  
										</select>
							   </td>

							   
							   <td>&nbsp;</td>							   
							 
						

								<td><select id="gainer_search_cat">
							          	<option value="">choose anyone</option>										  
							              <option value="No_of_trades">No of Trades</option>										  										     
							              <option value="Percent_Change">% Price</option>
							              <option value="Turnover">Turnover</option>
							              <option value="Volume">Volume</option>										  
							              <option value="market_cap">Market CAP</option>										  
							              <option value="eps">Eps</option>										  										  										  
										</select>
							   </td>
							   
						   </tr>
						   </table>
						   
						   
						   <div id="search_result"></div>
						
						</div>   
					   
						<?php 
						//$this->load->model("dailytop_gainer_data"); 
						//$this->load->model("dailytop_looser_data"); 		
						?>	
						<br/>		
						<table width="100%">
						<tr>
							<th style="background-color:#123456;color:#fff;">Top 10 Gainer  by Price</th>
							<td>&nbsp;&nbsp;&nbsp;&nbsp;</td>
							<th  style="background-color:#123456;color:#fff;">Top 10 Looser  by Price</th>
						</tr>
						<tr>
							<td>
								<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Prev Close Price</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Close Price</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">%Change</th>
								</tr>
								<?php  
									$prices = $this->load->get_var('prices');
									//= $this->dailytop_gainer_data->dailytop_gainer_by_price();
									$i=0;
									foreach($prices as $price)
									{ 
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   					
								?>
										<tr>
										  <td style="<?php echo $css;?>"><?php echo $price->Company_Code;?></td>
										  <td style="<?php echo $css;?>"><?php echo number_format($price->Prev_Close_Price, 2, '.', '');?></td>
										  <td style="<?php echo $css;?>"><?php echo number_format($price->Close_Price, 2, '.', '');?></td>
										  <td style="<?php echo $css;?>">						    
											  <?php echo number_format($price->Percent_Change, 2, '.', '');?>%
										  </td>
										</tr> 
								<?php 
									}
								?>
								</table>
							</td>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<td>
								<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th  style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Prev Close Price</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Close Price</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">%Change</th>
								</tr>
								<?php  
								$lprices = $this->load->get_var('lprices');
								//= $this->dailytop_looser_data->dailytop_looser_by_price();
								
									$i=0;
									foreach($lprices as $lprice)
									{ 
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   					
								?>
										<tr>
										  <td style="<?php echo $css;?>"><?php echo $lprice->Company_Code;?></td>
										  <td style="<?php echo $css;?>"><?php echo number_format($lprice->Prev_Close_Price, 2, '.', '');?></td>
										  <td style="<?php echo $css;?>"><?php echo number_format($lprice->Close_Price, 2, '.', '');?></td>
										  <td style="<?php echo $css;?>"><?php echo number_format($lprice->Percent_Change, 2, '.', '');?>%</td>
										</tr> 
								<?php 
									}
								?>
								</table>
							</td>			
						</tr>
						
						<tr>
						<td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td> 
						</tr>
						<tr>
							<th style="background-color:#123456;color:#fff;">Top 10 Gainer by Volume</th>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<th  style="background-color:#123456;color:#fff;">Top 10 Looser by Volume</th>
						</tr>
						
						<tr>
						<td>
							<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Volume</th>
								</tr>
								<?php 
								$gvolumes = $this->load->get_var('gvolumes');
								//= $this->dailytop_gainer_data->dailytop_gainer_by_volume_data();
								   $i=0;
								   foreach($gvolumes as $gvolume)
								   {
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   			   
								?>
								<tr>
									<td style="<?php echo $css;?>"><?php echo $gvolume->company_code;?></td>
									<td style="<?php echo $css;?>"><?php echo number_format($gvolume->volume, 2, '.', '');?></td>
								</tr>
								<?php } ?>
							</table>			
						</td>
						<td>&nbsp;&nbsp;&nbsp;</td>
						<td>	
							<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Volume</th>
								</tr>			
								<?php 
								$lvolumes =$this->load->get_var('lvolumes');
								//= $this->dailytop_looser_data->dailytop_looser_by_volume_data();
								   $i=0;
								   foreach($lvolumes as $lvolume){
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   			   
								?>
								<tr>
									<td style="<?php echo $css;?>"><?php echo $lvolume->company_code;?></td>
									<td style="<?php echo $css;?>"><?php echo number_format($lvolume->volume, 2, '.', '');?></td>
								</tr>
								<?php } ?>			
							</table>
						</td>		
						</tr>
						
						
						<tr>
						<td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td> 
						</tr>
						<tr>
							<th style="background-color:#123456;color:#fff;">Top 10 Gainer by Turnover</th>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<th  style="background-color:#123456;color:#fff;">Top 10 Looser by Turnover</th>
						</tr>		
						<tr>
						<td>
							<table width="100%">
							<tr>
								<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
								<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Turnover</th>
							</tr>
							<?php 
							$gturnovers = $this->load->get_var('gturnovers');
							//= $this->dailytop_gainer_data->dailytop_gainer_by_turnover_data();
							   $i=0;
							   foreach($gturnovers as $gturnover){
								   $i++;
								   if($i%2==0)
								   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
								   else
								   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   
							?>
							<tr>
								<td style="<?php echo $css;?>"><?php echo $gturnover->company_code;?></td>
								<td style="<?php echo $css;?>"><?php echo number_format($gturnover->turnover, 2, '.', '');?></td>
							</tr>
							<?php } ?>
							</table>			
						</td>
						<td>&nbsp;&nbsp;&nbsp;</td>
						<td>	
							<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Turnover</th>
								</tr>			
								<?php 
								$lturnovers = $this->load->get_var('lturnovers');
								//= $this->dailytop_looser_data->dailytop_looser_by_turnover_data();
								
								   $i=0;
								   foreach($lturnovers as $lturnover){
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   
								?>
								<tr>
									<td style="<?php echo $css;?>"><?php echo $lturnover->company_code;?></td>
									<td style="<?php echo $css;?>"><?php echo number_format($lturnover->turnover, 2, '.', '');?></td>
								</tr>
								<?php } ?>			
							</table>
						</td>		
						</tr>	


						
						
						
						<tr>
						<td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td> 
						</tr>
						<tr>
							<th style="background-color:#123456;color:#fff;">Top 10 Gainer by PE</th>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<th  style="background-color:#123456;color:#fff;">Top 10 Looser by PE</th>
						</tr>		
						<tr>
						<td>
							<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">PE</th>
								</tr>
								<?php 
								$gpes = $this->load->get_var('gpes');
								//$this->dailytop_gainer_data->dailytop_gainer_by_pe_data();
								   $i=0;
								   foreach($gpes as $gpe){
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   
								?>
								<tr>
									<td style="<?php echo $css;?>"><?php echo $gpe->company_code;?></td>
									<td style="<?php echo $css;?>"><?php echo number_format($gpe->pe, 2, '.', '');?></td>
								</tr>
								<?php } ?>
							</table>			
						</td>
						<td>&nbsp;&nbsp;&nbsp;</td>
						<td>	
							<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">PE</th>
								</tr>			
								<?php 
								//$lpes = $this->dailytop_looser_data->dailytop_looser_by_pe_data();
								   $i=0;
								   foreach($lpes as $lpe){
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   
								?>
								<tr>
									<td style="<?php echo $css;?>"><?php echo $lpe->company_code;?></td>
									<td style="<?php echo $css;?>"><?php echo number_format($lpe->pe, 2, '.', '');?></td>
								</tr>
								<?php } ?>			
							</table>
						</td>		
						</tr>			
						
						
						<tr>
						<td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td> 
						</tr>
						<tr>
							<th style="background-color:#123456;color:#fff;">Top 10 Gainer by Market CAP</th>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<th  style="background-color:#123456;color:#fff;">Top 10 Looser by Market CAP</th>
						</tr>		
						<tr>
						<td>
							<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Market CAP</th>
								</tr>
								<?php 
								$gmarketcap = $this->load->get_var('gmarketcap');
								//$this->dailytop_gainer_data->dailytop_gainer_by_pe_data();
								   $i=0;
								   foreach($gmarketcap as $gmktcap){
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   
								?>
								<tr>
									<td style="<?php echo $css;?>"><?php echo $gmktcap->company_code;?></td>
									<td style="<?php echo $css;?>"><?php echo number_format($gmktcap->market_cap, 2, '.', '');?></td>
								</tr>
								<?php } ?>
							</table>			
						</td>
						<td>&nbsp;&nbsp;&nbsp;</td>
						<td>	
							<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Market CAP</th>
								</tr>			
								<?php 
								$lmarketcap = $this->load->get_var('lmarketcap');
								   $i=0;
								   foreach($lmarketcap as $lmktcap){
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   
								?>
								<tr>
									<td style="<?php echo $css;?>"><?php echo $lmktcap->company_code;?></td>
									<td style="<?php echo $css;?>"><?php echo number_format($lmktcap->market_cap, 2, '.', '');?></td>
								</tr>
								<?php } ?>			
							</table>
						</td>		
						</tr>			


						<tr>
						<td colspan="3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td> 
						</tr>
						<tr>
							<th style="background-color:#123456;color:#fff;">Top 10 Gainer by EPS</th>
							<td>&nbsp;&nbsp;&nbsp;</td>
							<th  style="background-color:#123456;color:#fff;">Top 10 Looser by EPS</th>
						</tr>		
						<tr>
						<td>
							<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">EPS</th>
								</tr>
								<?php 
								    $geps = $this->load->get_var('geps');
								    //$this->dailytop_gainer_data->dailytop_gainer_by_pe_data();
								    $i=0;
								    foreach($geps as $gepss)
									{
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   
								?>
										<tr>
											<td style="<?php echo $css;?>"><?php echo $gepss->COMPANY_CODE;?></td>
											<td style="<?php echo $css;?>"><?php echo number_format($gepss->ANNUALIZED_EPS, 2, '.', '');?></td>
										</tr>
								<?php 
									} 
								?>
							</table>			
						</td>
						<td>&nbsp;&nbsp;&nbsp;</td>
						<td>	
							<table width="100%">
								<tr>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
									<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">EPS</th>
								</tr>			
								<?php 
								$leps = $this->load->get_var('leps');
								   $i=0;
								   foreach($leps as $lepss){
									   $i++;
									   if($i%2==0)
									   $css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
									   else
									   $css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   
								?>
								<tr>
									<td style="<?php echo $css;?>"><?php echo $lepss->COMPANY_CODE;?></td>
									<td style="<?php echo $css;?>"><?php echo number_format($lepss->ANNUALIZED_EPS, 2, '.', '');?></td>
								</tr>
								<?php } ?>			
							</table>
						</td>		
						</tr>									
						
						
						
						</table>
						
						   <script type="text/javascript">
							$(document).ready(function(){
							
						
								$("#gainer_search_key").bind("change",gainer_Table_Ordering);
								$("#looser_search_key").bind("change",looser_Table_Ordering);
							
								function gainer_Table_Ordering()
								{
									var  gsel_id = $("#gainer_search_key").val();
									 $("#search_result").load("<?php echo site_url();?>/daily_top_ui/trade_status_table",
									{'keyword':gsel_id},function(){});
									//alert(gsel_id);
								}
								
								function looser_Table_Ordering()
								{   
									var  lsel_id = $("#looser_search_key").val(); 
									 $("#search_result").load("<?php echo site_url();?>/daily_top_ui/trade_status_table",
									{'keyword':lsel_id},function(){});
									//alert(lsel_id);
								}
								
								$("#gainer_search_key").attr('disabled',true);
								$("#looser_search_key").attr('disabled',true);
								
								$("input[name='chk']").click(function(){
									var len = $("input[name='chk']:checked").length;
									var sel_id = $(this).attr('id');
									if(len>0)
									{
										$(".chk").each(function()
										{
											if(sel_id == $(this).attr('id')) 
											{
											   $(this).attr('checked',true);
											   $("#"+sel_id+"_search_key").attr('disabled',false);
											}
											else
											{
												$(this).attr('checked',false);						
												$("#"+$(this).attr('id')+"_search_key").attr('disabled',true);
											}
										});
									}
									else
									{
									   $("input[name='chk']").attr('checked',false);				   
									   $("#gainer_search_key").attr('disabled',true);
									   $("#looser_search_key").attr('disabled',true);
									}
								});
								
								$("#looser_search_key").change(function(){
									var sid = $("#looser_search_key").val();
									if(sid!="") {
									$("#search_result").load("<?php echo site_url();?>/dailytop_looser/"+sid,function(){});
									}else{
										$("#search_result").html("");
									  alert("Please select anyone");
									}
								});
								
								$("#gainer_search_key").change(function(){
									var sid = $("#gainer_search_key").val();
									if(sid!="") {
									   //alert(sid);
										$("#search_result").load("<?php echo site_url();?>/dailytop_gainer/"+sid,function(){});
									}else{
									  $("#search_result").html("");				
									  alert("Please select anyone");
									}
								});	
								
							});
						    </script> 
							 
							 
							 
							 

						
					</td>
				</tr>
				</table>
				
				
				
				
				
							
			
			
			
			
			
			

		</div><!---the bottom tens---->

    </div>
	</div>


    <!--main column end for body---> 
    <!--body end--> 
<script type="text/javascript">
$(document).ready(function() {

    $("#comp_id").change(function(){
	
	   var sid  = $(this).val();
	   //alert(sid);
	   if(sid!=""){
	   $("#basic_info_result").load("<?php echo site_url();?>/company_basic_info_ui/ui",{"company_code":sid},function(){});
	   }else{
	   $("#basic_info_result").html("");
	   }
	});

	$('#example').dataTable( {
		"aaSorting": [[ 1, "ASC" ]],
		"bPaginate": false
	});	

    $('#accordion .panel-collapse').on('shown.bs.collapse', function () {
       $(".glyphicon-chevron-down").removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
    });
    $('#accordion .panel-collapse').on('hidden.bs.collapse', function () {
       $(".glyphicon-chevron-up").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
    });

				
	$('#dp3').datepicker({
    startDate: "24/09/2013",
    orientation: "bottom auto",
    autoclose: true
    });

	$(".input-group.date").datepicker({ autoclose: true, //todayHighlight: true
    startDate: "24/09/2013",
	orientation: "bottom auto",
	});

	$('#dp4').datepicker({
    autoclose: true
    });
} );
</script>
<script src="<?php echo base_url();?>js/bootstrap.js"></script>
<!--
<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
-->
</body>
</html>