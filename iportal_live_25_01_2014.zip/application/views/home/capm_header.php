    
		<div class="col-md-3">
			<h1><img src="<?php echo base_url();?>img/iPortal.png" class="img-responsive" style="width:200px;height:50px;"></h1>
			<span style="font-weight:bold;">Financial Information for Prosperity</span>
		</div>
		<div class="col-md-9">
          <img src="<?php echo base_url();?>/img/pic1.png" style="margin-left:-11px;width:874px;height:100px;"/>
        </div>
    