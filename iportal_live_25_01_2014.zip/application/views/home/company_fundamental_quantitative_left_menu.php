<div class="sidebar-menu">
	<ul class="nav">	
		<li><a href="<?php echo site_url();?>/mains"                             class="left_menu" id="home">Home</a></li>	
		<li><a href="<?php echo site_url();?>/company_basic_info_ui" class="left_menu" id="company_basic_info_ui">Company Basic Info</a></li>
		<li><a href="<?php echo site_url();?>/daily_top_ui"                  class="left_menu" id="daily_top_ui">Daily Top</a></li>
		<li><a href="<?php echo site_url();?>/divident_details_ui"       class="left_menu" id="divident_details_ui">Dividend Details</a></li>
		<li><a href="<?php echo site_url();?>/weekly_top_ui"               class="left_menu" id="weekly_top_ui">Weekly Top</a></li>
		<li><a href="<?php echo site_url();?>/eps_npat_ui"                    class="left_menu" id="eps_npat_ui">EPS & NPAT</a></li>
		<li><a href="<?php echo site_url();?>/stock_vs_pe_ui"  				class="left_menu" id="stock_vs_pe_ui">Stock Vs Sector P/E</a></li>
		<li><a href="<?php echo site_url();?>/volatality_ui"  					class="left_menu" id="volatality_ui">Volatality</a></li>
		<li><a href="javascript:void(0);"   >Capital Gain</a></li>
		<li><a href="javascript:void(0);"   >Beta</a></li>
		<li><a href="<?php echo site_url();?>/mains/logout">Logout</a></li>		
	</ul>
</div>
