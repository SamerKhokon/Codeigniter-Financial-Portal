<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="content-type" content="text/html; charset=UTF-8">

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Home</title>

<?php $this->load->view("utility"); ?>

</head>
<body>
<div class="container"> 
 
    <!---header start----->	
    <div class="row">
		<?php $this->load->view("home/capm_header");?>
    </div>	
	
    <div class="row">
		<div class="col-md-12  placeholder">  </div>
	</div>

	<div class="row">
		<?php $this->load->view("home/capm_megamenu");?>
	</div> 
    <!---header end----> 

      

	  
	  
	  
    <!--body start---->
	<div class="row"> 

		<!--static sidebar menu---->
		<div class="col-md-3">
			<?php $this->load->view("home/company_fundamental_quantitative_left_menu");?>
		</div>
		<!--static sidebar menu end--->
		
		
		
		
		
		
		
		<div class="col-md-9">

			<div class="row">
				<div class="col-md-12 placeholder">
										<?php $this->load->view("home/company_fundamental_quantitative_submenu_overview");?>
				</div>
			</div>

			
			
                     <?php $codes = $this->load->get_var("codes");?>
					 
					<table width="50%">		
					<tr>
						<td>From</td>
						<td>To</td>	
						<td>Indicating Days</td>							
					</tr>					
					<tr>
						<td><input type="text" id="volatality_start_date"/></td>
						<td><input type="text" id="volatality_end_date"/></td>
						<td>
							<select id="indicating_days" >
								<option value="7">7</option>
								<option value="15">15</option>
								<option value="20">20</option>
								<option value="30">30</option>
								<option value="50">50</option>
							</select>
						</td>								
					</tr>					
					<tr>
					  <td colspan="2">
						Select Company: 
						</td>
					</tr>
					<tr>
						<td>
						<select id="company_code_01" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>			
					<td>
						<select id="company_code_02" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>							  
					</tr>
					
					<tr>
						<td>
						<select id="company_code_03" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>			
					<td>
						<select id="company_code_04" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>							  
					</tr>

					<tr>
						<td>
						<select id="company_code_05" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>			
					<td>
						<select id="company_code_06" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>							  
					</tr>

					<tr>
						<td>
						<select id="company_code_07" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>			
					<td>
						<select id="company_code_08" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>							  
					</tr>					
					
					
					<tr>
						<td>
						<select id="company_code_05" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>			
					<td>
						<select id="company_code_06" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>							  
					</tr>

					<tr>
						<td>
						<select id="company_code_09" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>			
					<td>
						<select id="company_code_10" >
							<option value="">Select Company</option>
						<?php 
							foreach($codes  as   $code) 
							{         
						?>
								<option value="<?php echo $code->CODE; ?>">
									<?php echo $code->CODE; ?>
								</option>
						<?php 
							} 
						?>
						</select>
					  </td>							  
					</tr>										
					<tr>
					<td><input type="button" id="volatality_show_result" value="Show Result"/></td>
					</tr>
					</table>
					
					<!--
					<tr>
					  <td><input type="button" id="sector_id_btn" class="btn btn-primary" value="Show Result" /></td>
					</tr>-->
					
					<table>					
					<tr>
					  <td>
					  	<script src="<?php echo base_url();?>js/charts/highcharts.js"></script>
						<script src="<?php echo base_url();?>js/charts/modules/exporting.js"></script>									  				  					
						<div id="volatality_graph_01"></div>
					  </td>
					  <td><div id="volatality_graph_02"></div></td>
					</tr>
					
					<tr>
					  <td><div id="volatality_graph_03"></div></td>
					  <td><div id="volatality_graph_04"></div></td>
					</tr>
					
					<tr>
					  <td><div id="volatality_graph_05"></div></td>
					  <td><div id="volatality_graph_06"></div></td>
					</tr>
					
					<tr>
					  <td><div id="volatality_graph_07"></div></td>
					  <td><div id="volatality_graph_08"></div></td>
					</tr>
					
					<tr>
					  <td><div id="volatality_graph_09"></div></td>
					  <td><div id="volatality_graph_10"></div></td>
					</tr>
					
				</table>
				
				
				
				
				
		
				<script type="text/javascript">
				$(document).ready(function()
				{		    
					$("#volatality_start_date").datepicker({changeMonth:true,changeYear:true,dateFormat:"dd-mm-yy"});
					$("#volatality_end_date").datepicker({changeMonth:true,changeYear:true,dateFormat:"dd-mm-yy"});	
						
					function generate_graph_one(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_01' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});
					}		

					function generate_graph_two(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_02' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});						
					}					
					
					
					function generate_graph_three(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_03' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});						
					}										

					
					function generate_graph_four(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_04' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});						
					}										
					
					
					function generate_graph_five(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_05' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});						
					}										
					
					
					function generate_graph_six(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_06' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});						
					}					


					function generate_graph_seven(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_07' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});						
					}										
					
					
					
					function generate_graph_eight(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_08' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});						
					}										
					
					
					function generate_graph_nine(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_09' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});						
					}										
					
					
					function generate_graph_ten(st)
					{
					    var dts = st[0].dates;					
						var sd  = st[1].sdeviation;				
					    
						var chart_01 = new Highcharts.Chart({
							chart:{
							    renderTo:'volatality_graph_10' ,
							  	width:400 ,
								heigh:250								
							}
							,
							title: {
								text: ''
							},
							xAxis: {
								categories: dts ,
								labels:{ rotation:-90 }
							},
							yAxis: {
								title: {
									text: ''
								},
								plotLines: [{
									value: 0,
									width: 1,
									color: '#808080'
								}]
							},
							tooltip: {
								valueSuffix: ''
							},
							credits:{ enabled:false} ,
							exporting:{enabled:false},
							series: [{	
                                name:"Volatality",							
								data: sd
								//[7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
							}]
						});						
					}										
					
					
					$("#volatality_show_result").bind("click", volatality_show_result);
					function volatality_show_result()
					{
					    var volatality_start_date = $("#volatality_start_date").val();
						var volatality_end_date  = $("#volatality_end_date").val();
						var indicating_days       = $("#indicating_days").val();
						
						var company_code_01  = $("#company_code_01").val();
						var company_code_02  = $("#company_code_02").val();
						var company_code_03  = $("#company_code_03").val();
						var company_code_04  = $("#company_code_04").val();
						var company_code_05  = $("#company_code_05").val();
						var company_code_06  = $("#company_code_06").val();
						var company_code_07  = $("#company_code_07").val();
						var company_code_08  = $("#company_code_08").val();
						var company_code_09  = $("#company_code_09").val();
						var company_code_10  = $("#company_code_10").val();
												
						if(company_code_01!="")
						{						    
							graph_for_company_one(volatality_start_date,volatality_end_date,indicating_days,company_code_01);
						}											
						
						if(company_code_02!="")
						{
							graph_for_company_two(volatality_start_date,volatality_end_date,indicating_days,company_code_02);
						}						
						
						if(company_code_03!=""){
							graph_for_company_three(volatality_start_date,volatality_end_date,indicating_days,company_code_03);
						}
						
						if(company_code_04!=""){
							graph_for_company_four(volatality_start_date,volatality_end_date,indicating_days,company_code_04);
						}
						
						if(company_code_05!=""){
							graph_for_company_five(volatality_start_date,volatality_end_date,indicating_days,company_code_05);
						}
						
						if(company_code_06!=""){
							graph_for_company_six(volatality_start_date,volatality_end_date,indicating_days,company_code_06);
						}
						
						if(company_code_07!=""){
							graph_for_company_seven(volatality_start_date,volatality_end_date,indicating_days,company_code_07);
						}
						
						if(company_code_08!=""){
							graph_for_company_eight(volatality_start_date,volatality_end_date,indicating_days,company_code_08);
						}
						
						if(company_code_09!=""){
							graph_for_company_nine(volatality_start_date,volatality_end_date,indicating_days,company_code_09);
						}
						
						if(company_code_10!=""){
							graph_for_company_ten(volatality_start_date,volatality_end_date,indicating_days,company_code_10);						
						}
						
					}
					
					
					function graph_for_company_one(volatality_start_date,volatality_end_date,indicating_days,company_code_01)
					{
					    //alert(company_code_01);
						$.ajax({
						    type:"post" ,
						    url:"<?php echo site_url();?>/volatality_ui/json_for_company_one" ,
						    data:"volatality_start_date="+volatality_start_date+"&volatality_end_date="+volatality_end_date+
								"&indicating_days="+indicating_days+"&company_code_01="+company_code_01 ,									
								
							dataType:'json',
							cache:false ,							
							success:function(st)
							{
								//alert(st[1].sdeviation);
								generate_graph_one(st);
							}									
						});
					
					}
					
					function graph_for_company_two(volatality_start_date,volatality_end_date,indicating_days,company_code_02)
					{
						$.ajax({
							type:"post" ,
							url:"<?php echo site_url();?>/volatality_ui/json_for_company_two" ,
							data:"volatality_start_date="+volatality_start_date+
									"&volatality_end_date="+volatality_end_date+"&indicating_days="+
									indicating_days+"&company_code_02="+company_code_02 ,									
							dataType:'json',		
							cache:false ,							
							success:function(st)
							{
								//alert(st[0].dates);
								generate_graph_two(st);
							}									
						});
					}

					function graph_for_company_three(volatality_start_date,volatality_end_date,indicating_days,company_code_03)
					{
					    $.ajax({
						   type:"post" ,
						   url:"<?php echo site_url();?>/volatality_ui/json_for_company_three" ,
						   data:"volatality_start_date="+volatality_start_date+
									"&volatality_end_date="+volatality_end_date+"&indicating_days="+
									indicating_days+"&company_code_03="+company_code_03 ,									
							dataType:'json',
							cache:false ,
							success:function(st)
							{
								generate_graph_three(st);
							}									
						});
					}

					function graph_for_company_four(volatality_start_date,volatality_end_date,indicating_days,company_code_04)
					{
					    $.ajax({
						   type:"post" ,
						   url:"<?php echo site_url();?>/volatality_ui/json_for_company_four" ,
						   data:"volatality_start_date="+volatality_start_date+
									"&volatality_end_date="+volatality_end_date+"&indicating_days="+
									indicating_days+"&company_code_04="+company_code_04 ,									
							dataType:'json',
							cache:false ,
							success:function(st)
							{
								generate_graph_four(st);
							}									
						});
					
					}

					function graph_for_company_five(volatality_start_date,volatality_end_date,indicating_days,company_code_05)
					{
						$.ajax({
						   type:"post" ,
						   url:"<?php echo site_url();?>/volatality_ui/json_for_company_five" ,
						   data:"volatality_start_date="+volatality_start_date+
									"&volatality_end_date="+volatality_end_date+"&indicating_days="+
									indicating_days+"&company_code_05="+company_code_05 ,									
							dataType:'json',
							cache:false ,							
							success:function(st)
							{
								generate_graph_six(st);
							}									
						});
					}

					function graph_for_company_six(volatality_start_date,volatality_end_date,indicating_days,company_code_06)
					{
						$.ajax({
						   type:"post" ,
						   url:"<?php echo site_url();?>/volatality_ui/json_for_company_six" ,
						   data:"volatality_start_date="+volatality_start_date+
									"&volatality_end_date="+volatality_end_date+"&indicating_days="+
									indicating_days+"&company_code_06="+company_code_06 ,									
							dataType:'json',		
							cache:false ,							
							success:function(st)
							{
								generate_graph_seven(st);
							}									
						});
					}

					function graph_for_company_seven(volatality_start_date,volatality_end_date,indicating_days,company_code_07)
					{
						$.ajax({
							type:"post" ,
							url:"<?php echo site_url();?>/volatality_ui/json_for_company_seven" ,
							data:"volatality_start_date="+volatality_start_date+
									"&volatality_end_date="+volatality_end_date+"&indicating_days="+
									indicating_days+"&company_code_07="+company_code_07 ,									
							dataType:'json',
							cache:false ,						
							success:function(st)
							{
								generate_graph_eight(st);
							}									
						});
					}

					function graph_for_company_eight(volatality_start_date,volatality_end_date,indicating_days,company_code_08)
					{
						$.ajax({
						   type:"post" ,
						   url:"<?php echo site_url();?>/volatality_ui/json_for_company_eight" ,
						   data:"volatality_start_date="+volatality_start_date+
									"&volatality_end_date="+volatality_end_date+"&indicating_days="+
									indicating_days+"&company_code_08="+company_code_08 ,									
							dataType:'json',
							cache:false ,							
							success:function(st)
							{
								generate_graph_nine(st);
							}									
						});
					}

					function graph_for_company_nine(volatality_start_date,volatality_end_date,indicating_days,company_code_09)
					{
					    $.ajax({
						   type:"post" ,
						   url:"<?php echo site_url();?>/volatality_ui/json_for_company_nine" ,
						   data:"volatality_start_date="+volatality_start_date+
									"&volatality_end_date="+volatality_end_date+"&indicating_days="+
									indicating_days+"&company_code_09="+company_code_09 ,									
							dataType:'json',		
							cache:false ,							
							success:function(st)
							{
								generate_graph_ten(st);
							}									
						});
					}

					function graph_for_company_ten(volatality_start_date,volatality_end_date,indicating_days,company_code_10)
					{
					    $.ajax({
						   type:"post" ,
						   url:"<?php echo site_url();?>/volatality_ui/json_for_company_ten" ,
						   data:"volatality_start_date="+volatality_start_date+
									"&volatality_end_date="+volatality_end_date+"&indicating_days="+
									indicating_days+"&company_code_10="+company_code_10 ,									
							cache:false ,
							dataType:'json',
							success:function(st)
							{
								alert(st);
							}									
						});
					}					
				});
				</script>	

		</div><!---the bottom tens---->

    </div>
	</div>


    <!--main column end for body---> 
    <!--body end--> 
<script type="text/javascript">
$(document).ready(function() {

    $("#comp_id").change(function(){
	
	   var sid  = $(this).val();
	   //alert(sid);
	   if(sid!=""){
	   $("#basic_info_result").load("<?php echo site_url();?>/company_basic_info_ui/ui",{"company_code":sid},function(){});
	   }else{
	   $("#basic_info_result").html("");
	   }
	});

	$('#example').dataTable( {
		"aaSorting": [[ 1, "ASC" ]],
		"bPaginate": false
	});	

    $('#accordion .panel-collapse').on('shown.bs.collapse', function () {
       $(".glyphicon-chevron-down").removeClass("glyphicon-chevron-down").addClass("glyphicon-chevron-up");
    });
    $('#accordion .panel-collapse').on('hidden.bs.collapse', function () {
       $(".glyphicon-chevron-up").removeClass("glyphicon-chevron-up").addClass("glyphicon-chevron-down");
    });

				
	$('#dp3').datepicker({
    startDate: "24/09/2013",
    orientation: "bottom auto",
    autoclose: true
    });

	$(".input-group.date").datepicker({ autoclose: true, //todayHighlight: true
    startDate: "24/09/2013",
	orientation: "bottom auto",
	});

	$('#dp4').datepicker({
    autoclose: true
    });
} );
</script>
<script src="<?php echo base_url();?>js/bootstrap.js"></script>
<!--
<script type="text/javascript" language="javascript" src="js/jquery.js"></script>
-->
</body>
</html>