<!-- main page -->
<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	  
		<meta name="keywords"    content="Bootstrap Tutorial"/>
		<meta name="description" content="Custom template making with bootstrap framework."/>	  
		<meta name="author"      content="Samer Sarker Khokon. 01719347580"/>	  
	  
		<?php $this->load->view('utility');?>
		
		
	  <title>IP: <?php echo $_SERVER['REMOTE_ADDR'];?></title>
	</head>
<body>   
	
	<div class="well">	
		<table width="100%">	
			<tr>
				<td width="35%"><img src="<?php echo base_url();?>img/iPortal.png"/></td>
				<td width="30%">&nbsp;&nbsp;&nbsp;&nbsp;
				<input type="button" class="btn btn-primary" value="Login"/>
				<input type="button" class="btn btn-primary" value="Register"/>
				&nbsp;&nbsp;&nbsp;&nbsp;				
				</td>				
				<td width="35%"><img src="<?php echo base_url();?>img/Pic1.png"/></td>
			</tr>
		</table>
		
			<span class="glyphicon glyphicon-home"></span><a href="javascript:void(0);">Home</a>
			<span class="glyphicon glyphicon-user"></span>Online: <?php echo $this->session->userdata("CAPM_USER");?> &nbsp;
			<a href="<?php echo site_url();?>/mains/logout/" ><span class="glyphicon glyphicon-off"></span>Logout</a>

			<?php $this->load->view("home/capm_megamenu"); ?>
			<!-- end megamenu -->			
	</div>	
	
	<div class="container"> 
	    <div class="row">
		    <div class="col-md-12">
			    <marquee loop="-1">stock market prices scroll here 
				stock market prices scroll here 
				stock market prices scroll here 
				stock market prices scroll here
				stock market prices scroll here
				stock market prices scroll here
				stock market prices scroll here</marquee>
			</div>
		</div>
	    <div class="row">
	        <div class="col-md-3">
		      <!-- left menu -->
			  <?php $this->load->view("home/todays_market_left_menu");?>
			</div>			
			
			<div class="col-md-9">	
			    <table width="100%">
				<tr><td>
                <?php //$this->load->view("home/todays_market_submenu_overview");  ?>			
				</td></tr>
				<tr>
					<td>
					
				

								<div class="panel panel-default">
									<div class="panel-heading">Option1</div>
										<div class="panel-body">
										
										
										<?php $companies = $this->load->get_var('companies'); ?>
										
										<table width="100%">
											<tr>
											<td><input type="text" id="option_01_start_date" class="form-control"/></td>
											<td><input type="text"  id="option_01_end_date" class="form-control"/></td>											
											</tr>
											<tr>
												<td>
													<select id="code_01" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>
												<td>
													<select id="code_02" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>												
											</tr>

											
											
											
											<tr>
												<td>
													<select id="code_03" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>
												<td>
													<select id="code_04" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>												
											</tr>


											<tr>
												<td>
													<select id="code_05" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>
												<td>
													<select id="code_05" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>												
											</tr>

											<tr>
												<td>
													<select id="code_06" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>
												<td>
													<select id="code_07" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>												
											</tr>



											<tr>
												<td>
													<select id="code_09" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>
												<td>
													<select id="code_10" class="form-control">
													<option value="">select company</option>
													<?php foreach($companies as $company){ ?>
													<option value="<?php echo $company->CODE;?>"><?php echo $company->CODE;?></option>
													<?php }?>
													</select>												
												</td>												
											</tr>
											<tr>											
											<td colspan="2">
											<input type="button" class="btn btn-primary" id="capital_gain_option_01_show_result_btn" value="Show Result"/>
											</td>
											</tr>
											
											
										</table>

										</div>
									</div>
										
										
										
								<div class="panel panel-default">
										<div class="panel-heading">Option2</div>
										<div class="panel-body">	
										
										<table width="100%">
										
											<tr>
											<td><input type="text" id="option_02_start_date" class="form-control"/></td>
											<td><input type="text"  id="option_02_end_date" class="form-control"/></td>											
											</tr>
										
											<tr>
											  <td colspan="2">
												Select Sector:  
												<select id="sector_id" class="form-control">
													<option value="">Select Sector</option>
												<?php 
													foreach($sectors  as   $sector) 
													{         
												?>
														<option value="<?php echo $sector->SECTOR; ?>">
															<?php echo $sector->SECTOR; ?>
														</option>
												<?php 
													} 
												?>
												</select>
											  </td>				  
											</tr>
											<tr>
											  <td><input type="button" id="sector_id_btn" class="btn btn-primary" value="Show Result" /></td>
											</tr>
											<tr>
												<td>
													<script src="<?php echo base_url();?>js/charts/highcharts.js"></script>
													<script src="<?php echo base_url();?>js/charts/modules/exporting.js"></script>									  				  
													<div id="container_x01"></div>
												</td>					
											</tr>
										</table>
										
								
									</div>
								</div> 
							
						
						    <div class="panel panel-default">
								<div class="panel-heading">Option3</div>
								<div class="panel-body">	
										
										<table width="100%">										
											<tr>
											<td><input type="text" id="option_03_start_date" class="form-control"/></td>
											<td><input type="text"  id="option_03_end_date" class="form-control"/></td>											
											</tr>											
										</table>
								</div>			
							</div>
						
						
						
						<div id="capital_gain_common_search_result"></div>
						

						
					</td>
				</tr>
				</table>
			</div>
	   </div>
	</div>
				
	
	
	<script type="text/javascript" src="<?php echo base_url();?>js/bootstrap.min.js"></script>		
	<script type="text/javascript">
	$(document).ready(function(){
	    $(this).bind("contextmenu", function(e) {
            e.preventDefault();
        });
		
		
		$("#capital_gain_option_01_show_result_btn").bind("click" , capital_gain_option_01_show_result_btn);
		function capital_gain_option_01_show_result_btn()
		{
			var option_01_start_date = $("#option_01_start_date").val();	
			var option_01_end_date   = $("#option_01_end_date").val();				
			var code_01 = $("#code_01").val();
			var code_02 = $("#code_02").val();
			var code_03 = $("#code_03").val();
			var code_04 = $("#code_04").val();
			var code_05 = $("#code_05").val();
			var code_06 = $("#code_06").val();
			var code_07 = $("#code_07").val();
			var code_08 = $("#code_08").val();
			var code_09 = $("#code_09").val();
			var code_10 = $("#code_10").val();
			
			$.ajax({
			   type:"post" ,
			   url:"<?php echo site_url();?>/capital_gain_ui/get_end_price_of_date" ,
			   data: "option_01_start_date="+option_01_start_date+
						"&option_01_end_date="+option_01_end_date+			   
						"&code_01="+code_01+"&code_02="+code_02
						+"&code_03="+code_03+"&code_04="+code_04+
						"&code_05="+code_05+"&code_06="+code_06
						+"&code_07="+code_07+"&code_08="+code_08+
						"&code_09="+code_09+"&code_10="+code_10	,
			   cache:false ,
			   success:function(st) {
			     //alert(st);
				 $("#capital_gain_common_search_result").html(st);
			   }
			});
			
			//alert(option_01_start_date);
		}
		
		
		//$("#capital_gain_common_search_result").load("<?php echo site_url();?>/capital_gain_ui/capital_gain_search_result_table" , function(){});
		
		
		$("#option_01_start_date").datepicker({ dateFormat:"dd-mm-yy",changeMonth:true,changeYear:true });
		$("#option_01_end_date").datepicker({ dateFormat:"dd-mm-yy",changeMonth:true,changeYear:true });				
		
		
		$("#option_02_start_date").datepicker({ dateFormat:"dd-mm-yy",changeMonth:true,changeYear:true });
		$("#option_02_end_date").datepicker({ dateFormat:"dd-mm-yy",changeMonth:true,changeYear:true });		
		
		
		$("#option_03_start_date").datepicker({ dateFormat:"dd-mm-yy",changeMonth:true,changeYear:true });
		$("#option_03_end_date").datepicker({ dateFormat:"dd-mm-yy",changeMonth:true,changeYear:true });				
		
	});
	</script>
	
</body>
</html>