  <!-- include jquery -->  
<!-- include jquery 
	<script src="<?php //echo base_url();?>simplify/src/js/jquery-1.10.1.min.js"></script>    

  <link rel="stylesheet" href="<?php //echo base_url();?>simplify/css/bootstrap.min.css" />
  <script src="<?php //echo base_url();?>simplify/src/js/bootstrap.min.js"></script>
-->  
  
<!--  <link rel="stylesheet" href="../css/font-awesome.min.css" />-->
  <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css" />


  <!-- code mirror -->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>simplify/css/codemirror.min.css" />
  <link rel="stylesheet" href="<?php echo base_url();?>simplify/css/blackboard.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>simplify/css/monokai.min.css">
  <script type="text/javascript" src="<?php echo base_url();?>simplify/src/js/codemirror.js"></script>
  <script src="<?php echo base_url();?>simplify/src/js/xml.min.js"></script>
  <script src="<?php echo base_url();?>simplify/src/js/formatting.min.js"></script>

    <!-- include summernote -->
    <link rel="stylesheet" href="<?php echo base_url();?>simplify/dist/summernote.css">
    <script type="text/javascript" src="<?php echo base_url();?>simplify/dist/summernote.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
		  $('.summernote').summernote({
			height: 150,	
			tabsize: 2,
			codemirror: {
			  theme: 'monokai'
			}
		  });
		});
		</script>
  