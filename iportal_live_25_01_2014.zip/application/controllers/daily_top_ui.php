<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Daily_top_ui extends CI_Controller 
{
    public function index()
	{
	    $this->load->model("dailytop_gainer_data"); 
		$this->load->model("dailytop_looser_data"); 
		
		$prices         = $this->dailytop_gainer_data->dailytop_gainer_by_price();
		$lprices        = $this->dailytop_looser_data->dailytop_looser_by_price();
		$gvolumes   = $this->dailytop_gainer_data->dailytop_gainer_by_volume_data();
		$lvolumes     = $this->dailytop_looser_data->dailytop_looser_by_volume_data();
		$gturnovers = $this->dailytop_gainer_data->dailytop_gainer_by_turnover_data();
		$lturnovers  = $this->dailytop_looser_data->dailytop_looser_by_turnover_data();		
		$gpes            = $this->dailytop_gainer_data->dailytop_gainer_by_pe_data();		
		$lpes             = $this->dailytop_looser_data->dailytop_looser_by_pe_data();
				
		$data['gmarketcap'] = $this->dailytop_gainer_data->dailytop_gainer_by_marketcap_data();		
		$data['lmarketcap'] = $this->dailytop_looser_data->dailytop_looser_by_marketcap_data();
	
	    $data['geps'] = $this->dailytop_gainer_data->dailytop_gainer_by_eps_data();
	    $data['leps']  = $this->dailytop_looser_data->dailytop_looser_by_eps_data();
	
	
	
		$this->load->model("menu_data");
	    $data['menu_overview']      = $this->menu_data->get_menu_overview("Company Fundamentals & Quantitative");
	    $data['submenu_overview'] = $this->menu_data->get_submenu_overview("daily_top_ui");
			
		//$data[''] = $this->dailytop_gainer_data->dailytop_gainer_by_marketcap_data();			
			
		$data['prices']          = $prices;				
		$data['lprices']         = $lprices;
		
		$data['gvolumes']    = $gvolumes;
		$data['lvolumes']     = $lvolumes;
		
		$data['gturnovers'] = $gturnovers;
		$data['lturnovers']  = $lturnovers;
		
		$data['gpes'] = $gpes;
		$data['lpes']  = $lpes;
		
		
		$this->load->vars($data);
		
		
	   //$this->load->view("home/capm_login_and_home_page");
	   $this->load->view("home/daily_top_ui_view");
	}
	
	
	
	
	public function trade_status_table()
	{  
	
	    error_reporting(0);
		$user_keyword  =  $this->input->post("keyword");
		$parse = explode("#", $user_keyword); 
		
		$field = $parse[0];
		$order = $parse[1];
		
		$this->load->model("dailytop_gainer_data");
		$trades = $this->dailytop_gainer_data->trade_status_table_data($field,$order);
		$this->load->view('utility');
?>
        <br/>
        <script type="text/javascript" charset="utf-8">
		$(document).ready(function() {
			/*$('#example').dataTable({					    
				"aaSorting": [[ 1 , "asc" ]],
				"aaSorting": [[ 2 , "asc", "desc" ]],
				"aaSorting": [[ 3 , "asc", "desc" ]],
				"aaSorting": [[ 4 , "asc", "desc" ]],
				"aaSorting": [[ 5 , "asc", "desc" ]],
				"sPaginationType": "full_numbers"
			});*/
		});
		</script>
		<!-- <div id="demo">-->
		<table width="100%"  cellpadding="0" cellspacing="0" border="0" class="display" id="example">
		<thead>
		<tr>
			<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Company Code</th>
			<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">% Price</th>
			<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Turnover</th>
			<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;">Volume</th>			
			<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;text-align:center;">No of Trades</th>						
			<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;text-align:center;">Market CAP</th>									
			<th style="background-color:#ABC;font-family: tahoma,Arial;font-size:12px;text-align:center;">EPS</th>												
		</tr>
		</thead>
		<tbody>
	<?php 	
	    $i=0;	
		foreach($trades as $trade)
		{
		    $i++;
			if($i%2==0)
			$css  = "background-color:#FFFFFF;font-family: tahoma,Arial;font-size:12px;";
			else
			$css = "background-color:#F6FAFD;font-family: tahoma,Arial;font-size:12px;";			   
 
?>		
			<tr class="gradeA">
				<td style="<?php echo $css;?>"><?php echo $trade->Company_Code;?></td>
				<td style="<?php echo $css;?>">
					<?php if($trade->Percent_Change <0 ){  ?>	
					<span style="color:#B9000D;"><?php echo number_format($trade->Percent_Change, 2, '.', '');?>%</span>   
				   <?php }else{?>
					<span style="color:green;"><?php echo number_format($trade->Percent_Change, 2, '.', '');?>%</span>   
				   <?php }?>	
				</td>
				<td style="<?php echo $css;?>"><?php echo number_format($trade->Turnover, 2, '.', '') ;?></td>
				<td style="<?php echo $css;?>"><?php echo number_format($trade->Volume, 2, '.', '');?></td>
				<td style="<?php echo $css;?>text-align:center;"><?php echo number_format($trade->No_of_Trades, 0, '.', '');?></td>
			    <td style="<?php echo $css;?>text-align:center;"><?php echo $trade->market_cap;?></td>
			    <td style="<?php echo $css;?>text-align:center;"><?php echo $trade->eps;?></td>				
			</tr>	
		<?php 	
		}
		?>
		</tbody>
		</table>
		<!-- </div>-->
		<br/><br/>		
	<?php 	
	}
	

	
	
}
?>