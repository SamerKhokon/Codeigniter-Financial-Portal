<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Capital_gain_ui extends CI_Controller 
{
    public function index()
	{
		$this->load->model("sector_vs_eps_data");		
		$this->load->model("input_form_data");
		
				
		$companies = $this->input_form_data->company_code_for_combo();
		$sectors   = $this->sector_vs_eps_data->get_sectors();
		
		$data['companies'] = $companies;
		$data['sectors']   = $sectors;
		
		
	
		
		$this->load->vars($data);
		
	    $this->load->view("home/capital_gain_ui_view");
	}
	
	public function capital_gain_search_result_table()
	{
	?>
	   <table  width="100%">
		<tr>
		   <th rowspan="2" style="background-color:#123456;color:#fff;text-align:center;font-family: tahoma,Arial;">Company Name</th>
		   <th rowspan="2" style="background-color:#669999;color:#fff;text-align:center;font-family: tahoma,Arial;">Beg. Price</th>
		   <th rowspan="2" style="background-color:#3399ff;color:#fff;text-align:center;font-family: tahoma,Arial;">End Price</th>
		   <th rowspan="2" style="background-color:#123456;color:#fff;text-align:center;font-family: tahoma,Arial;">Capital Gain</th>
		   <th rowspan="2" style="background-color:#999966;color:#fff;text-align:center;font-family: tahoma,Arial;">Year</th>
		   <th colspan="2" style="background-color:#993300;color:#fff;text-align:center;font-family: tahoma,Arial;">Declaration</th>
		   <th rowspan="2" style="background-color:#123456;color:#fff;text-align:center;font-family: tahoma,Arial;">Declaration Date</th>
		</tr>
		<tr>		  
		  <th style="background-color:#E2A76F;color:#fff;text-align:center;font-family: tahoma,Arial;">Stock</th>
		  <th style="background-color:#FFA62F;color:#fff;text-align:center;font-family: tahoma,Arial;">Cash</th>
		</tr>
		
			<tr>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
			</tr>
		
		
	</table>		
	<?php 
	}
	
	
	public function get_end_price_of_date()
	{
	   $this->load->model("capital_gain_data");
	   
	   $date_start   = $this->input->post("option_01_start_date");
	   $date_end     = $this->input->post("option_01_end_date");	   
	   $company_code1 = $this->input->post("code_01");
	   $company_code2 = $this->input->post("code_02");
	   $company_code3 = $this->input->post("code_03");
	   $company_code4 = $this->input->post("code_04");
	   $company_code5 = $this->input->post("code_05");
	   $company_code6 = $this->input->post("code_06");
	   $company_code7 = $this->input->post("code_07");
	   $company_code8 = $this->input->post("code_08");
	   $company_code9 = $this->input->post("code_09");
	   $company_code10 = $this->input->post("code_10");
	   
	   
	   
	   $codes = array($company_code1 , $company_code2 , $company_code3 ,
	   $company_code4 , $company_code5 , $company_code6 ,
	   $company_code7 , $company_code8 , $company_code9 , $company_code10);
	   
		
	   print_r($codes);
	   
	   ?>
	   
	   
	    <table  width="100%">
		<tr>
		   <th rowspan="2" style="background-color:#123456;color:#fff;text-align:center;font-family: tahoma,Arial;">Company Name</th>
		   <th rowspan="2" style="background-color:#669999;color:#fff;text-align:center;font-family: tahoma,Arial;">Beg. Price</th>
		   <th rowspan="2" style="background-color:#3399ff;color:#fff;text-align:center;font-family: tahoma,Arial;">End Price</th>
		   <th rowspan="2" style="background-color:#123456;color:#fff;text-align:center;font-family: tahoma,Arial;">Capital Gain</th>
		   <th rowspan="2" style="background-color:#999966;color:#fff;text-align:center;font-family: tahoma,Arial;">Year</th>
		   <th colspan="2" style="background-color:#993300;color:#fff;text-align:center;font-family: tahoma,Arial;">Declaration</th>
		   <th rowspan="2" style="background-color:#123456;color:#fff;text-align:center;font-family: tahoma,Arial;">Declaration Date</th>
		</tr>
		<tr>		  
		  <th style="background-color:#E2A76F;color:#fff;text-align:center;font-family: tahoma,Arial;">Stock</th>
		  <th style="background-color:#FFA62F;color:#fff;text-align:center;font-family: tahoma,Arial;">Cash</th>
		</tr>
		
		<?php
		foreach($codes  as $code) 
		{
		   if($code!="")
		    {
			
			   $end_price = $this->capital_gain_data->get_end_price($date_start,$code);
			   $beg_price = $this->capital_gain_data->get_end_price($date_end,$code);	   
			   if($beg_price!="")
			   {
				$capital_gain = (($end_price-$beg_price)/$beg_price)*100;
				//echo "b:$beg_price e:$end_price c:$capital_gain";
			  
		?>

			<tr>
				<td style="background-color:#FFF;color:#000;text-align:center;"><?php echo $code;?></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"><?php echo $beg_price;?></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"><?php echo $end_price;?></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"><?php echo $capital_gain;?></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
				<td style="background-color:#FFF;color:#000;text-align:center;"></td>
			</tr>
			<?php 
			     }
			}	   
		}
		?>
		
	</table>	
	   
	   
	   <?php 
	  
	}
	
	public function capital_gain_option_one_search_result()
	{
	    
	}
	
	
	public function capital_gain_option_two_search_result()
	{
	    
	}
	
	
	public function capital_gain_option_three_search_result()
	{
	    
	}
	
}
?>	