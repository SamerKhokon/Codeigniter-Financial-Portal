<?php
    public function page_traker($page_id)
	{
	   $this->load->model("page_traker_data");
	}
?>