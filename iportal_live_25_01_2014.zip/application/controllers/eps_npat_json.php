<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Eps_npat_json extends CI_Controller 
{

	public function yealy_eps_json()
	{
	   $company_code = $this->input->post("company_id");
	   $this->load->model("eps_npat_data");
	   $yeps = $this->eps_npat_data->yearly_eps_data($company_code);
	   
	   foreach($yeps as $yp)
	   {
	      $years[] = $yp->YEAR;
		  $yr_eps[] = (float)$yp->QUARTER_4_12M;
	   }
	   
	   $t[] = array("data"=>$years);	   
	   $t[] = array("data"=>$yr_eps);
	   echo json_encode($t);
	}


	public function yearly_nav_shares_json()
	{
	   $company_code = $this->input->post("company_id");
	   $this->load->model("eps_npat_data");
	   $year_datas = $this->eps_npat_data->yearly_nav_data($company_code);
	   foreach($year_datas as $year_data)
	   {
			$years[] = $year_data->YEAR;
	   }
	   
	   $eps_continue_data = $this->eps_npat_data->yearly_nav_shares_data($company_code);
	   foreach($eps_continue_data as $eps_cont_data)
	   {
			$shares[] = (float)$eps_cont_data->NAV_PERSHARE;
	   }
	   $t[0] = array("data"=>$years);
	   $t[1] = array("data"=>$shares);
	   echo json_encode($t);	   
	}	

	public function net_profit_all_quarter_continuing_json()
	{
	  $company_code = $this->input->post("company_id");
	  $this->load->model("eps_npat_data");	  
	  $firsts = $this->eps_npat_data->net_profit_year_continuing_data($company_code);
	  	  
	  foreach($firsts as $first)
	  {
	    $years[] = (int)$first->YEAR;
	  }	  
	  
	  $eps_continue_data = $this->eps_npat_data->net_profit_all_quarter_continuing_data($company_code);	  
	  foreach($eps_continue_data as $eps_cont_data)
	  {
		$q1_3m[] = (float)$eps_cont_data->QUARTER_1_3M ;
		$q2_6m[] = (float)$eps_cont_data->QUARTER_2_6M ;
		$q3_9m[] = (float)$eps_cont_data->QUARTER_3_9M ;
		$q4_12m[] = (float)$eps_cont_data->QUARTER_4_12M ;
	  }	    
	  
	  $t[0] = array("name"=>"categories", "data"=>$years);
	  $t[1] = array("name"=>"Q1","data"=>$q1_3m);
	  $t[2] = array("name"=>"Q2","data"=>$q2_6m);
	  $t[3] = array("name"=>"Q3","data"=>$q3_9m);
	  $t[4] = array("name"=>"Q4","data"=>$q4_12m);
	  echo json_encode($t);
	}


	public function eps_all_quarter_continuing_json()
	{
	
	  $company_code = $this->input->post("company_id");
	  $this->load->model("eps_npat_data");
	  
	  $eps_years = $this->eps_npat_data->eps_continuing_years_data($company_code);
	  foreach($eps_years as $eps_year)
	  {
	    $years[] = (int)$eps_year->YEAR;
	  }	  
	  
	  $eps_continue_data = $this->eps_npat_data->eps_continuing_all_quarter_data($company_code);
	  
	  foreach($eps_continue_data as $eps_cont_data)
	  {
		$q1_3m[] = (float)$eps_cont_data->QUARTER_1_3M ;
		$q2_6m[] = (float)$eps_cont_data->QUARTER_2_6M ;
		$q3_9m[] = (float)$eps_cont_data->QUARTER_3_9M ;
		$q4_12m[] = (float)$eps_cont_data->QUARTER_4_12M ;
	  }	  
	  $t[0] = array("name"=>"categories","data"=>$years);
	  $t[1] = array("name"=>"Q1","data"=>$q1_3m);
	  $t[2] = array("name"=>"Q2","data"=>$q2_6m);
	  $t[3] = array("name"=>"Q3","data"=>$q3_9m);
	  $t[4] = array("name"=>"Q4","data"=>$q4_12m);
	  
	  echo json_encode($t);
	}	


	public function net_profit_first_quarter_continuing_json()
	{
		$company_code = $this->input->post("company_id");
		$this->load->model("eps_npat_data");	  
	    $firsts = $this->eps_npat_data->net_profit_year_continuing_data($company_code);
	  	  
	  foreach($firsts as $first)
	  {
	    $years[] = (int)$first->YEAR;
	  }
	  
	  
	  $eps_continue_data = $this->eps_npat_data->net_profit_first_quarter_continuing_data($company_code);	  
	  foreach($eps_continue_data as $eps_cont_data)
	  {
		$q1_3m[] = (float)$eps_cont_data->QUARTER_1_3M ;
		$q2_3m[] = (float)$eps_cont_data->QUARTER_2_3M ;
		$q3_3m[] = (float)$eps_cont_data->QUARTER_3_3M ;
		$q4_3m[] = (float)$eps_cont_data->QUARTER_4_3M ;
	  }	    
	  
	  $t[0] = array("name"=>"categories","data"=>$years);
	  $t[1] = array("name"=>"Q1","data"=>$q1_3m);
	  $t[2] = array("name"=>"Q2","data"=>$q2_3m);
	  $t[3] = array("name"=>"Q3","data"=>$q3_3m);
	  $t[4] = array("name"=>"Q4","data"=>$q4_3m);
	  echo json_encode($t);
	}




    public function eps_first_quarter_continuing_json()
	{
	  $company_code = $this->input->post("company_id");
	  
	  
	  $this->load->model("eps_npat_data");	
	  $eps_years = $this->eps_npat_data->eps_continuing_years_data($company_code);
	  foreach($eps_years as $eps_year)
	  {
	    $years[] = (float)$eps_year->YEAR;
	  }
	  
	  $eps_continue_data = $this->eps_npat_data->eps_continuing_first_quarter_data($company_code);
	  foreach($eps_continue_data as $eps_cont_data)
	  {
		$q1_3m[] = (float)$eps_cont_data->QUARTER_1_3M ;
		$q2_3m[] = (float)$eps_cont_data->QUARTER_2_3M ;
		$q3_3m[] = (float)$eps_cont_data->QUARTER_3_3M ;
		$q4_3m[] = (float)$eps_cont_data->QUARTER_4_3M ;
	  }	    
	  $t[0] = array("name"=>"categories","data"=>$years);
	  $t[1] = array("name"=>"Q1","data"=>$q1_3m);
	  $t[2] = array("name"=>"Q2","data"=>$q2_3m);
	  $t[3] = array("name"=>"Q3","data"=>$q3_3m);
	  $t[4] = array("name"=>"Q4","data"=>$q4_3m);
	  echo json_encode($t);
	}


    public function share_distribution_json()
	{
	    $company_code = $this->input->post("company_id");
		$this->load->model("eps_npat_data");
		$shares = $this->eps_npat_data->share_distribution_data($company_code);
		$parse  = explode("#" , $shares);
		
		$sponsor   = (float)$parse[0];
		$govt      = (float)$parse[1];
		$institute = (float)$parse[2];
		$foreign   = (float)$parse[3];
		$publics   = (float)$parse[4];
		
		$t[] =  array("data"=>
					array(	
						array("Sponsor:$sponsor%",$sponsor),
						array("Govt:$govt%",$govt),
						array("Institute:$institute%",$institute),
						array("Foreign:$foreign%",$foreign),
						array("Publics:$publics%",$publics)
					)
				);
		echo json_encode($t);		
	}
	
	public function scope_to_pay_divident_json()
	{
	//"ACI";//
	    $company_code = $this->input->post("company_id");
		$this->load->model("eps_npat_data");
		$shares = $this->eps_npat_data->scope_to_pay_divident_data($company_code);
		$parse  = explode("#" , $shares);
		
		$paidup   = (float)$parse[0];
		$scope   = (float)$parse[1];
		
		//$paidup_r =  number_format($paidup,2,'.','');
		//$scope_r   =  number_format($scope,2,'.','');
		
		
		
		$t[] =  array("data"=>
					array(	
						array("Dividend Possible:".$scope."%",$scope),
						array("Paidup:".$paidup."%",  $paidup  )						
					)
				);
		echo json_encode($t);	
		
	}
}
?>