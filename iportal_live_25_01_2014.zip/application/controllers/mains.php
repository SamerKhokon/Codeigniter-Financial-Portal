<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mains extends CI_Controller 
{
    public function index()
	{
	
	   $this->load->model("dailytop_gainer_data");
	    $this->load->model("dailytop_looser_data");
	   
	   $data['top_turnovers'] = $this->dailytop_gainer_data->dailytop_gainer_by_turnover_data();
	   $this->load->vars($data);
	   //$this->load->view("home/capm_login_and_home_page");
	   $this->load->view("home/home_page");
	}
	
	
	public function capm_login_check()
	{
		$username = $this->input->post("username");
		$password = $this->input->post("password");
		
		if($username=="capm" && $password == "capm@bd")
		{
			$this->session->set_userdata("CAPM_USER",$username);
			$this->session->set_userdata("IP",$_SERVER["REMOTE_ADDR"]);
			$this->session->set_userdata("LOGIN_TIME",date("Y-m-d h:i:s"));
			echo 1;
		}
		else
		{
			echo 0;
		}
	}
	
	public function logout()
	{
	   $this->session->unset_userdata("CAPM_USER");
	   $this->session->unset_userdata("IP");
	   $this->session->unset_userdata("LOGIN_TIME");
	   redirect("/mains","refresh");
	}
	
	
}
?>