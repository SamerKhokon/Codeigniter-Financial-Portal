<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Divident_details_ui extends CI_Controller 
{
	public function index()
	{
	
	    $this->load->model("input_form_data");
		$codes1 = $this->input_form_data->company_code_for_combo();		
	    $sects = $this->input_form_data->get_sectors();
		
		   $this->load->model("menu_data");
	   $data['menu_overview'] = $this->menu_data->get_menu_overview("Company Fundamentals & Quantitative");
	   $data['submenu_overview'] = $this->menu_data->get_submenu_overview("divident_details_ui");
	
		$data['codes1'] = $codes1;
		$data['sects'] = $sects;
		$this->load->vars($data);
		
		$this->load->view("home/divident_details_ui_view");	
	}
}
?>