<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Weekly_top_ui extends CI_Controller 
{
	public function index()
	{
		$this->load->model("weeklytop_gainer_data"); 
		$this->load->model("weeklytop_looser_data"); 	
		$g_prices = $this->weeklytop_gainer_data->dailytop_gainer_by_price();
		$l_prices = $this->weeklytop_looser_data->dailytop_looser_by_percent_change();
		$g_volume = $this->weeklytop_gainer_data->dailytop_gainer_by_volume_data();
		$l_volume = $this->weeklytop_looser_data->dailytop_looser_by_volume_data();
		$g_turnover = $this->weeklytop_gainer_data->dailytop_gainer_by_turnover_data();						
		$l_turnover = $this->weeklytop_looser_data->dailytop_looser_by_turnover_data();
		$g_no_of_trade = $this->weeklytop_gainer_data->dailytop_gainer_by_no_of_trades_data();		
		$l_no_of_trade = $this->weeklytop_looser_data->dailytop_looser_by_no_of_trades_data();		
           $this->load->model("menu_data");
	   $data['menu_overview'] = $this->menu_data->get_menu_overview("Company Fundamentals & Quantitative");
	  $data['submenu_overview'] = $this->menu_data->get_submenu_overview("weekly_top_ui");
	
		
		$data['g_prices'] = $g_prices;
		$data['l_prices'] = $l_prices;
		$data['g_volume'] = $g_volume;
		$data['l_volume'] = $l_volume;
		$data['g_turnover'] = $g_turnover;
		$data['l_turnover'] = $l_turnover;
		$data['g_no_of_trade'] = $g_no_of_trade;
		$data['l_no_of_trade'] = $l_no_of_trade;
		$this->load->vars($data);
		$this->load->view("home/weekly_top_ui_view");	
	}
}
?>